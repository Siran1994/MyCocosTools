import { _decorator, Component, Node } from 'cc';
import { AgentConfig, NavMeshComponent } from '../../nav-mesh/nav-mesh-component';
import { Vec3 } from 'cc';
import { EventTouch } from 'cc';
import { Camera } from 'cc';
import { geometry } from 'cc';
import { PhysicsSystem } from 'cc';
import { PhysicsRayResult } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('main')
export class main extends Component {
    @property({ type: [Node] })
    nodes: Node[] = [];
    @property({ type: Camera })
    camera: Camera = null;
    @property({ type: NavMeshComponent })
    navMesh: NavMeshComponent = null;

    private navMeshCrowdId: number = 0;
    private _agentIds: number[] = [];
    private _touchId: any = null;
    private _ray: geometry.Ray = new geometry.Ray();
    start() {
        this.navMesh.build();
        this.navMesh.bakeDebugBuild();
        this.navMeshCrowdId = this.navMesh.createCrowd(10, 1);
        let config: AgentConfig = {
            radius: 1,
            height: 2,
            maxAcceleration: 100,
            maxSpeed: 3,
            collisionQueryRange: 6,    //排斥的距离 距离多少的时候计算排斥
            pathOptimizationRange: 3,
            separationWeight:3,    //确保代理之间的距离
        }
        for (let i = 0; i < this.nodes.length; i++) {
            let id: number = this.navMesh.addAgent(this.navMeshCrowdId, this.nodes[i], config);
            this._agentIds.push(id);
        }


        this.node.on(Node.EventType.TOUCH_START, this.touchStart, this);
        this.node.on(Node.EventType.TOUCH_MOVE, this.touchMove, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.touchEnd, this);
        this.node.on(Node.EventType.TOUCH_END, this.touchEnd, this);
    }
    private touchStart(event: EventTouch): void {
        if (this._touchId != null) return;
        this._touchId = event.getID();
        let x = event.getLocation().x;
        let y = event.getLocation().y;

        this.camera.screenPointToRay(x, y, this._ray);
        if (PhysicsSystem.instance.raycastClosest(this._ray)) {
            let raycastClosestResult: PhysicsRayResult = PhysicsSystem.instance.raycastClosestResult;
            let pos: Vec3 = raycastClosestResult.hitPoint;
            console.log(pos);
            for (let i = 0; i < this._agentIds.length; i++) {
                this.navMesh.moveAgent(this.navMeshCrowdId, this._agentIds[i], pos);
            }

        } else {

        }
    }
    private touchMove(event: EventTouch): void {

    }
    private touchEnd(event: EventTouch): void {
        if (this._touchId != event.getID()) return;
        this._touchId = null;
    }
    update(deltaTime: number) {

    }
}


