System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, v3, math, _dec, _class, _crd, ccclass, property, RagdollBone;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      v3 = _cc.v3;
      math = _cc.math;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "402d2FQlftCEq4QHdigqn8m", "RagdollBone", undefined);

      __checkObsolete__(['_decorator', 'director', 'Component', 'Node', 'Vec3', 'v3', 'math']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("RagdollBone", RagdollBone = (_dec = ccclass('RagdollBone'), _dec(_class = class RagdollBone extends Component {
        constructor(...args) {
          super(...args);
          this.simuNode = null;
          this.initPos = v3();
          this.initRot = new math.Quat();
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=f5f4389f05edf1c8251ecec65a7367baec09063b.js.map