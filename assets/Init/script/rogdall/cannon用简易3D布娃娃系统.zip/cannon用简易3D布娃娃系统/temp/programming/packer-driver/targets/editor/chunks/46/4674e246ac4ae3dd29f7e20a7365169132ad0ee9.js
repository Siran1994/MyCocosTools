System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, PhysicsSystem, RigidBody, _dec, _class, _crd, ccclass, property, RagdollCANNON;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      PhysicsSystem = _cc.PhysicsSystem;
      RigidBody = _cc.RigidBody;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a58e5Vcz3BF1rxL5rKJKGg/", "RagdollCANNON", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'PhysicsSystem', 'RigidBody']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("RagdollCANNON", RagdollCANNON = (_dec = ccclass('RagdollCANNON'), _dec(_class = class RagdollCANNON extends Component {
        constructor(...args) {
          super(...args);
          this.world = PhysicsSystem.instance.physicsWorld.impl;
        }

        start() {
          this.initRagdoll();
        }

        initRagdoll() {
          const head = this.node.getChildByName("head").getComponent(RigidBody);
          const upperBody = this.node.getChildByName("upperBody").getComponent(RigidBody);
          const pelvis = this.node.getChildByName("pelvis").getComponent(RigidBody);
          const upperArmL = this.node.getChildByName("upperArmL").getComponent(RigidBody);
          const lowerArmL = this.node.getChildByName("lowerArmL").getComponent(RigidBody);
          const upperArmR = this.node.getChildByName("upperArmR").getComponent(RigidBody);
          const lowerArmR = this.node.getChildByName("lowerArmR").getComponent(RigidBody);
          const upperLegL = this.node.getChildByName("upperLegL").getComponent(RigidBody);
          const lowerLegL = this.node.getChildByName("lowerLegL").getComponent(RigidBody);
          const upperLegR = this.node.getChildByName("upperLegR").getComponent(RigidBody);
          const lowerLegR = this.node.getChildByName("lowerLegR").getComponent(RigidBody); // Neck joint

          this.buildJoint(head.body.impl, upperBody.body.impl, {
            pivotA: new CANNON.Vec3(0, 0, -0.9),
            pivotB: new CANNON.Vec3(0, 0, 0.9),
            axisA: new CANNON.Vec3(0, 0, 1),
            axisB: new CANNON.Vec3(0, 0, 1),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          }); // Knee joints

          this.buildJoint(lowerLegL.body.impl, upperLegL.body.impl, {
            pivotA: new CANNON.Vec3(0, 0, 0.75),
            pivotB: new CANNON.Vec3(0, 0, -0.75),
            axisA: new CANNON.Vec3(0, 0, 1),
            axisB: new CANNON.Vec3(0, 0, 1),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          });
          this.buildJoint(lowerLegR.body.impl, upperLegR.body.impl, {
            pivotA: new CANNON.Vec3(0, 0, 0.75),
            pivotB: new CANNON.Vec3(0, 0, -0.75),
            axisA: new CANNON.Vec3(0, 0, 1),
            axisB: new CANNON.Vec3(0, 0, 1),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          }); // Hip joints

          this.buildJoint(upperLegL.body.impl, pelvis.body.impl, {
            pivotA: new CANNON.Vec3(0, 0, 0.75),
            pivotB: new CANNON.Vec3(-0.75, 0, -0.6),
            axisA: new CANNON.Vec3(0, 0, 1),
            axisB: new CANNON.Vec3(0, 0, 1),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          });
          this.buildJoint(upperLegR.body.impl, pelvis.body.impl, {
            pivotA: new CANNON.Vec3(0, 0, 0.75),
            pivotB: new CANNON.Vec3(0.75, 0, -0.6),
            axisA: new CANNON.Vec3(0, 0, 1),
            axisB: new CANNON.Vec3(0, 0, 1),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          }); // Spine

          this.buildJoint(pelvis.body.impl, upperBody.body.impl, {
            pivotA: new CANNON.Vec3(0, 0, 0.6),
            pivotB: new CANNON.Vec3(0, 0, -0.9),
            axisA: new CANNON.Vec3(0, 0, 1),
            axisB: new CANNON.Vec3(0, 0, 1),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          }); // Shoulders

          this.buildJoint(upperBody.body.impl, upperArmL.body.impl, {
            pivotA: new CANNON.Vec3(-0.75, 0, 0.9),
            pivotB: new CANNON.Vec3(0.6, 0, 0),
            axisA: new CANNON.Vec3(1, 0, 0),
            axisB: new CANNON.Vec3(1, 0, 0),
            angle: Math.PI / 3,
            twistAngle: Math.PI / 8
          });
          this.buildJoint(upperBody.body.impl, upperArmR.body.impl, {
            pivotA: new CANNON.Vec3(0.75, 0, 0.9),
            pivotB: new CANNON.Vec3(-0.6, 0, 0),
            axisA: new CANNON.Vec3(1, 0, 0),
            axisB: new CANNON.Vec3(1, 0, 0),
            angle: Math.PI / 3,
            twistAngle: Math.PI / 8
          }); // Elbow joint

          this.buildJoint(lowerArmL.body.impl, upperArmL.body.impl, {
            pivotA: new CANNON.Vec3(0.6, 0, 0),
            pivotB: new CANNON.Vec3(-0.6, 0, 0),
            axisA: new CANNON.Vec3(1, 0, 0),
            axisB: new CANNON.Vec3(1, 0, 0),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          });
          this.buildJoint(lowerArmR.body.impl, upperArmR.body.impl, {
            pivotA: new CANNON.Vec3(-0.6, 0, 0),
            pivotB: new CANNON.Vec3(0.6, 0, 0),
            axisA: new CANNON.Vec3(1, 0, 0),
            axisB: new CANNON.Vec3(1, 0, 0),
            angle: Math.PI / 4,
            twistAngle: Math.PI / 8
          });
        }

        buildJoint(bodyA, bodyB, options) {
          const joint = new CANNON.ConeTwistConstraint(bodyA, bodyB, options);
          this.world.addConstraint(joint);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4674e246ac4ae3dd29f7e20a7365169132ad0ee9.js.map