System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, SkeletalAnimation, Ragdoll, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, Test;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfRagdoll(extras) {
    _reporterNs.report("Ragdoll", "../Ragdoll/Ragdoll", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      SkeletalAnimation = _cc.SkeletalAnimation;
    }, function (_unresolved_2) {
      Ragdoll = _unresolved_2.Ragdoll;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8582bpjPWlGc5U3T8QchvDs", "Test", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'SkeletalAnimation']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Test", Test = (_dec = ccclass('Test'), _dec2 = property(Node), _dec3 = property(SkeletalAnimation), _dec(_class = (_class2 = class Test extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "target", _descriptor, this);

          _initializerDefineProperty(this, "skeletalAnimation", _descriptor2, this);
        }

        onTouchEnd() {
          var _this$skeletalAnimati, _this$skeletalAnimati2, _this$skeletalAnimati3;

          let ragdoll = this.target.getComponent(_crd && Ragdoll === void 0 ? (_reportPossibleCrUseOfRagdoll({
            error: Error()
          }), Ragdoll) : Ragdoll);
          let isEnabled = ragdoll.getEnabled(); // 开启布娃娃之后动作会被覆盖，强烈建议停止动画

          let name = (_this$skeletalAnimati = this.skeletalAnimation) == null ? void 0 : _this$skeletalAnimati.defaultClip.name;
          isEnabled ? (_this$skeletalAnimati2 = this.skeletalAnimation) == null ? void 0 : _this$skeletalAnimati2.crossFade(name, 0) : (_this$skeletalAnimati3 = this.skeletalAnimation) == null ? void 0 : _this$skeletalAnimati3.stop();
          ragdoll.setEnabled(!isEnabled);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "target", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "skeletalAnimation", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0983798b42b8156c3184b52f25c9bf4d6637782c.js.map