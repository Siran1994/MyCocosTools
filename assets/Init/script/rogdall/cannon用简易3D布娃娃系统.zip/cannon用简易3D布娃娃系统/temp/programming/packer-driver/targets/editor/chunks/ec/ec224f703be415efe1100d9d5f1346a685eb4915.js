System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, CCFloat, Component, Node, v3, Vec3, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, RagdollConstraint;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      CCFloat = _cc.CCFloat;
      Component = _cc.Component;
      Node = _cc.Node;
      v3 = _cc.v3;
      Vec3 = _cc.Vec3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "562d4BUeSdJvbgRR36Qz6IB", "RagdollConstraint", undefined);

      __checkObsolete__(['_decorator', 'CCClass', 'CCFloat', 'Component', 'director', 'Node', 'v3', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("RagdollConstraint", RagdollConstraint = (_dec = ccclass('RagdollConstraint'), _dec2 = property(Node), _dec3 = property(Vec3), _dec4 = property(Vec3), _dec5 = property(Vec3), _dec6 = property(Vec3), _dec7 = property(CCFloat), _dec8 = property(CCFloat), _dec(_class = (_class2 = class RagdollConstraint extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "connectedBone", _descriptor, this);

          _initializerDefineProperty(this, "pivotA", _descriptor2, this);

          _initializerDefineProperty(this, "pivotB", _descriptor3, this);

          _initializerDefineProperty(this, "axisA", _descriptor4, this);

          _initializerDefineProperty(this, "axisB", _descriptor5, this);

          _initializerDefineProperty(this, "angle", _descriptor6, this);

          _initializerDefineProperty(this, "twistAngle", _descriptor7, this);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "connectedBone", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "pivotA", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return v3();
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "pivotB", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return v3();
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "axisA", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return v3();
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "axisB", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return v3();
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "angle", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return Math.PI / 4;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "twistAngle", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return Math.PI / 8;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ec224f703be415efe1100d9d5f1346a685eb4915.js.map