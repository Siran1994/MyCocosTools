System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, PhysicsSystem, RigidBody, SphereCollider, RagdollBone, RagdollConstraint, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, Ragdoll;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfRagdollBone(extras) {
    _reporterNs.report("RagdollBone", "./RagdollBone", _context.meta, extras);
  }

  function _reportPossibleCrUseOfRagdollConstraint(extras) {
    _reporterNs.report("RagdollConstraint", "./RagdollConstraint", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      PhysicsSystem = _cc.PhysicsSystem;
      RigidBody = _cc.RigidBody;
      SphereCollider = _cc.SphereCollider;
    }, function (_unresolved_2) {
      RagdollBone = _unresolved_2.RagdollBone;
    }, function (_unresolved_3) {
      RagdollConstraint = _unresolved_3.RagdollConstraint;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fc0eb4iDgpE04mibrjf0fSC", "Ragdoll", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'PhysicsGroup', 'PhysicsSystem', 'RigidBody', 'SphereCollider']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Ragdoll", Ragdoll = (_dec = ccclass('Ragdoll'), _dec2 = property(Node), _dec(_class = (_class2 = class Ragdoll extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "rootNode", _descriptor, this);

          this.realBones = [];
          this.simuBones = [];
          this.simuBoneJointArr = [];
          this.world = void 0;
          this.isEnabled = false;
        }

        start() {
          this.world = PhysicsSystem.instance.physicsWorld.impl;
          this.initRagdoll();
        }

        initRagdoll() {
          // 压入真实骨骼
          this.getAllRealBones(this.rootNode); // 创建模拟骨骼

          this.createSimuBones(); // 创建模拟骨骼的关节

          this.createSimuBoneJoints();
        }

        createSimuBones() {
          for (let boneNode of this.realBones) {
            let node = new Node();
            node.addComponent(SphereCollider).radius = 0.2;
            node.addComponent(RigidBody);
            this.node.addChild(node);
            this.simuBones.push(node);
            this.syncPositionAndRotation(node, boneNode); // 同步之后将位置赋给初始位置

            let ragdollBone = boneNode.getComponent(_crd && RagdollBone === void 0 ? (_reportPossibleCrUseOfRagdollBone({
              error: Error()
            }), RagdollBone) : RagdollBone);
            ragdollBone.simuNode = node;
            ragdollBone.initPos = boneNode.getPosition();
            ragdollBone.initRot = boneNode.getRotation();
          }

          this.scheduleOnce(() => {
            for (let bone of this.simuBones) {
              let body = bone.getComponent(RigidBody);
              body.sleep();
            }
          }, 0);
        }

        createSimuBoneJoints() {
          for (let boneNode of this.realBones) {
            const joint = boneNode.getComponent(_crd && RagdollConstraint === void 0 ? (_reportPossibleCrUseOfRagdollConstraint({
              error: Error()
            }), RagdollConstraint) : RagdollConstraint);

            if (joint) {
              const simuNodeA = boneNode.getComponent(_crd && RagdollBone === void 0 ? (_reportPossibleCrUseOfRagdollBone({
                error: Error()
              }), RagdollBone) : RagdollBone).simuNode;
              const simuNodeB = joint.connectedBone.getComponent(_crd && RagdollBone === void 0 ? (_reportPossibleCrUseOfRagdollBone({
                error: Error()
              }), RagdollBone) : RagdollBone).simuNode;
              const bodyA = simuNodeA.getComponent(RigidBody).body.impl;
              const bodyB = simuNodeB.getComponent(RigidBody).body.impl;
              let spineJoint = new CANNON.ConeTwistConstraint(bodyA, bodyB, {
                pivotA: new CANNON.Vec3(joint.pivotA.x, joint.pivotA.y, joint.pivotA.z),
                pivotB: new CANNON.Vec3(joint.pivotB.x, joint.pivotB.y, joint.pivotB.z),
                axisA: new CANNON.Vec3(joint.axisA.x, joint.axisA.y, joint.axisA.z),
                axisB: new CANNON.Vec3(joint.axisB.x, joint.axisB.y, joint.axisB.z),
                angle: joint.angle,
                twistAngle: joint.twistAngle
              });
              this.world.addConstraint(spineJoint);
              this.simuBoneJointArr.push(spineJoint);
            }
          }
        }

        getAllRealBones(node) {
          let bones = node.children;

          for (let boneNode of bones) {
            const bone = boneNode.getComponent(_crd && RagdollBone === void 0 ? (_reportPossibleCrUseOfRagdollBone({
              error: Error()
            }), RagdollBone) : RagdollBone);

            if (bone) {
              this.realBones.push(boneNode);
            }

            this.getAllRealBones(boneNode);
          }
        }

        update(deltaTime) {
          if (this.isEnabled) {
            this.updateBones();
          }
        }

        syncPositionAndRotation(nodeA, nodeB) {
          nodeA.setWorldPosition(nodeB.worldPosition);
          nodeA.setWorldRotation(nodeB.worldRotation);
        } // 将模拟骨骼的位置和转角同步到真实骨骼


        updateBones() {
          for (let i = 0; i < this.realBones.length; i++) {
            this.syncPositionAndRotation(this.realBones[i], this.simuBones[i]);
          }
        }

        getEnabled() {
          return this.isEnabled;
        }

        setEnabled(isEnabled) {
          isEnabled ? this.enableRagdoll() : this.disableRagdoll();
        }

        enableRagdoll() {
          // 将模拟骨骼的位置和真实骨骼同步
          for (let bone of this.realBones) {
            let ragdollBone = bone.getComponent(_crd && RagdollBone === void 0 ? (_reportPossibleCrUseOfRagdollBone({
              error: Error()
            }), RagdollBone) : RagdollBone);
            this.syncPositionAndRotation(ragdollBone.simuNode, bone);
          }

          for (let bone of this.simuBones) {
            let body = bone.getComponent(RigidBody);
            body.wakeUp();
          } // 将关节添加至物理世界


          for (let joint of this.simuBoneJointArr) {
            this.world.addConstraint(joint);
          }

          this.isEnabled = true;
        }

        disableRagdoll() {
          // 将真实骨骼移动至初始位置
          for (let bone of this.realBones) {
            let ragdollBone = bone.getComponent(_crd && RagdollBone === void 0 ? (_reportPossibleCrUseOfRagdollBone({
              error: Error()
            }), RagdollBone) : RagdollBone);
            bone.setPosition(ragdollBone.initPos);
            bone.setRotation(ragdollBone.initRot);
          }

          for (let bone of this.simuBones) {
            let body = bone.getComponent(RigidBody);
            body.sleep();
          } // 从物理世界中移除关节


          for (let joint of this.simuBoneJointArr) {
            this.world.removeConstraint(joint);
          }

          this.isEnabled = false;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rootNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=718ab123b7093de0d6ec36a1db45a1a96d901240.js.map