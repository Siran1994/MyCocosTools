import { _decorator, Component, Node, SkeletalAnimation } from 'cc';
import { Ragdoll } from '../Ragdoll/Ragdoll';
const { ccclass, property } = _decorator;

@ccclass('Test')
export class Test extends Component {
    @property(Node)
    target: Node = null;

    @property(SkeletalAnimation)
    skeletalAnimation: SkeletalAnimation = null;

    onTouchEnd() {
        let ragdoll = this.target.getComponent(Ragdoll)
        let isEnabled = ragdoll.getEnabled();

        // 开启布娃娃之后动作会被覆盖，强烈建议停止动画
        let name = this.skeletalAnimation?.defaultClip.name;
        isEnabled ? this.skeletalAnimation?.crossFade(name, 0) : this.skeletalAnimation?.stop();
        ragdoll.setEnabled(!isEnabled);
    }
}


