import { _decorator, director, Component, Node, Vec3, v3, math } from "cc";
const { ccclass, property } = _decorator

@ccclass('RagdollBone')
export class RagdollBone extends Component {
    simuNode: Node = null;
    initPos: Vec3 = v3();
    initRot: math.Quat = new math.Quat();
}