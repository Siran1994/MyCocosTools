import { _decorator, CCClass, CCFloat, Component, director, Node, v3, Vec3 } from "cc";
const { ccclass, property } = _decorator

@ccclass('RagdollConstraint')
export class RagdollConstraint extends Component {
    @property(Node)
    connectedBone: Node = null;

    @property(Vec3)
    pivotA: Vec3 = v3()

    @property(Vec3)
    pivotB: Vec3 = v3()

    @property(Vec3)
    axisA: Vec3 = v3()

    @property(Vec3)
    axisB: Vec3 = v3()

    @property(CCFloat)
    angle: number = Math.PI / 4;

    @property(CCFloat)
    twistAngle: number = Math.PI / 8;
}