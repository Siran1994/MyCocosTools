import { PlatformsAPI } from "../PlatformsAPI";
import GameIdConfig from "../GameIdConfig";
import InsManager from "../../manager/InsManager";
import { KpOpenType, ToastType } from "../../data/GameData";
import RewardsManager from "../../manager/RewardsManager";
import { PathData } from "../../data/PathData";
import PropData from "../../data/PropData";
import Platforms from "../Platforms";

export default class oppoH5GameAPI implements PlatformsAPI {

    videoType: string;

    arg: any;

    /**平台环境 */
    qg: any = window["qg"];
    /**banner广告 */
    bannerAd: any = null;
    /**插屏广告 */
    interstitialAd: any = null;
    /**视频广告 */
    rewardedVideoAd: any = null;
    /**视频广告是否已经load到数据 */
    m_videoAdIsLoaded: boolean = false;
    /**原生 */
    nativeAd: any = null;
    /**原生load取值 */
    resTemp: any = null;

    /**原生icon load取值 */
    resIconTemp: any = null;

    nativeIconAd: any = null;

     /** 互推盒子 广告 */
    gameBannerAd:any=null;

    gamePortalAd:any=null;

    /**系统信息 */
    systemInfo: any = null;
 
    private isShowNative: boolean = false;


    /**初始化 */
    onInit(_callback: Function) {
        if (this.qg !== null && this.qg !== undefined) {
            this.systemInfo = this.qg.getSystemInfoSync();
            this.qg.setEnableDebug({
                enableDebug: false, // true 为打开，false 为关闭
                success: function () {
                    console.log("test consol log");
                },
                complete: function () {
                },
                fail: function () {
                }
            });

            this.qg.reportMonitor( 'game_scene', 0); //检测数据崩溃
        //   this.createVideo();
        //   this.showNativeAd();
        //   this.showNativeIconAd();
        } else {
            this.qg = null;
            console.error("qg==NULL")
        }

        _callback && _callback();

        Laya.timer.once(50000 , this , ()=>{ this.isShowNative = true ; console.log('可以展示原生了'); });

        // if(this.systemInfo.platformVersionCode<1076){
        //     console.log('快应用平台版本号低于1076，暂不支持互推盒子相关 API')
            
        // }
        console.log("oppoH5GameAPI=============================>:onInit");
    }
    /**登录*/
    onLogin() {
    }
    /**分享游戏链接 */
    onShare(_success:Function) {

    }
    /**分享录屏 */
    onShareVideo(_callback: Function) {

    }
    /**创建banner */
    createBanner() {

    }
    /**展示banner */
    showBanner(id: string) {
        return;
        console.log(parseInt( Laya.LocalStorage.getItem("bannerHideCount")));
        Laya.LocalStorage.setItem("bannerHideCount" , (parseInt( Laya.LocalStorage.getItem("bannerHideCount")) + 1).toString() );

        if (this.qg !== null && this.qg !== undefined && parseInt( Laya.LocalStorage.getItem("bannerHideCount")) < 5 ) {
            if (this.systemInfo.platformVersionCode < 1051) {
                console.log("版本号过低 无法创建横幅广告");
                return;
            }
            this.hideBanner();
            // TipUtils.showTip("Oppo平台 创建横幅广告");
            this.bannerAd = this.qg.createBannerAd({
                adUnitId: id
            });
            this.bannerAd.show();
            this.bannerAd.onShow(() => {
                console.log("横幅广告调用 onShow");

            });
            this.bannerAd.onHide(() => {
                Laya.LocalStorage.setItem("bannerHideCount" , (parseInt( Laya.LocalStorage.getItem("bannerHideCount")) + 1).toString() );
                console.log("手动隐藏Banner:" +  Laya.LocalStorage.getItem("bannerHideCount"));
            });
            this.bannerAd.onLoad(function () {
                console.log('banner 广告加载成功');
            });
            this.bannerAd.onError(function (err) {
                console.log("banner 拉取 失败：", err.errCode , "errMsg:"  ,err.errMsg);
            })
        }else{
           // console.log("banner 显示上限了");
        }
        console.log("oppoH5GameAPI showBanner:" , id);
    }
    /**隐藏banner */
    hideBanner() {
        if (this.bannerAd) {
            //   TipUtils.showTip("Oppo平台 销毁横幅广告");
            this.bannerAd.destroy();
            this.bannerAd = null;
        }
        console.log("oppoH5GameAPI hideBanner");
    }
    /**创建激励视频 */
    createVideo(id: string , callBack: Function) {
        console.log("创建激励视频=============:" + id);
        if (this.qg !== null && this.qg !== undefined) {
            if (this.systemInfo.platformVersionCode < 1051) {
                console.log("版本号过低 无法创建激励视频广告");
                return;
            }
            if (this.rewardedVideoAd) {
                //   TipUtils.showTip("Oppo平台 销毁激励视频广告");
                this.rewardedVideoAd.destroy();
                this.rewardedVideoAd = null;
            }
            /**创建rewardedVideoAd 对象*/
            //  TipUtils.showTip("Oppo平台 创建激励视频广告");
            this.rewardedVideoAd = this.qg.createRewardedVideoAd({
                adUnitId: id
            });
            this.rewardedVideoAd.load();
            this.rewardedVideoAd.onLoad(() => {
                console.log("激励视频加载成功");
                //     TipUtils.showTip("激励视频广告 加载成功");
                this.m_videoAdIsLoaded = true;
                callBack && callBack();
            });
            this.rewardedVideoAd.onError((err) => {
                console.log(id);
                console.log('激励视频错误码 =====>:' + err.errMsg + "message ======>:" + err.errMsg);
                InsManager.GetInstance()._UIManager.ShowGameToast('视频创建失败，请稍后试试吧！' , ToastType.Game );
                //     TipUtils.showTip("激励视频广告 加载失败");
                this.m_videoAdIsLoaded = false;
            });
        }
        console.log("Create RewardeVideoAd");
    }
    /**
     * 
     * @param _type 类型
     * @param _arg 参数
     * @param _successCallback 成功回调
     * @param _failCallback 失败回调
     */
    /**展示激励视频 */
    showVideo(id: string,  _successCallback?: Function, _failCallback?: Function) {
        if(this.qg){
            this.createVideo(id , ()=>{
                /**确保video正常创建并已经拉取到数据 */
                if (this.rewardedVideoAd && this.m_videoAdIsLoaded) {
                    if(RewardsManager.GetInstance().isShowKnapsackPanel) InsManager.GetInstance()._UIManager.ShowKnapsackPanel( KpOpenType.EquipmentList , InsManager.GetInstance()._knapsackManager.FindKnapsackData(PathData.Knapsack_EquipmentColumn ,  PropData.GetInstance().knapsackData).id , PropData.GetInstance().knapsackData);
                    this.rewardedVideoAd.show();
                    const onClose = (res) => {
                        if (res.isEnded) {
                            console.log('激励视频广告完成，发放奖励')
                            /**播放完毕 处理播放成功的逻辑 */
                            _successCallback && _successCallback();
                        } else {
                            console.log('激励视频广告取消关闭，不发放奖励')
                             InsManager.GetInstance()._UIManager.ShowGameToast('未观看完整视频无法获取奖励' , ToastType.Game);
                            /**播放失败 处理播放失败的逻辑 */
                            _failCallback && _failCallback();
                        }
                        this.rewardedVideoAd.offClose(onClose);
                    }
                    this.rewardedVideoAd.onError(function(err) {
                       // InsManager.GetInstance()._UIManager.ShowGameToast('视频错误码：'+ err.errCode , ToastType.Game );
                       InsManager.GetInstance()._UIManager.ShowGameToast('视频加载失败，请稍后试试吧！' , ToastType.Game );
                        console.log("视频错误========", err.errCode , err.errMsg);
                    });
                    this.rewardedVideoAd.onClose(onClose);
                } else {
                    /**没有成功创建广告或者没有成功load广告 就重新创建一个 */
                    InsManager.GetInstance()._UIManager.ShowGameToast('广告还未准备好,请稍后再试' , ToastType.Game);
                }
            });
        }else{
            InsManager.GetInstance()._UIManager.ShowGameToast('广告还未准备好,请稍后再试' , ToastType.Game );
        }
     
     
        console.log("显示OPPO RewardeVideoAd:" , id);
    }
    /**----------原生平台调用----------
     * 激励视频播放成功后调用(OC->TS || JAVA->TS) 
     */
    showVideoAward() {
        this.videoType = "";
        this.arg = null;
    }
    /**----------原生平台调用----------
     * 激励视频播放失败后调用(OC->TS || JAVA->TS) 
     */
    showVideoFail() {
        this.videoType = "";
        this.arg = null;
    }
    /**创建插屏 */
    createInsertAd() {

    }
    /**展示插屏 */
    showInsertAd() {
        if (this.qg != null && this.qg != undefined) {
            if (this.systemInfo.platformVersionCode < 1051) {
                console.log("版本号过低 无法创建插屏广告");
                return;
            }
            if (this.interstitialAd) {
                //    TipUtils.showTip("Oppo平台 销毁插屏广告");
                this.interstitialAd.destroy();
                this.interstitialAd = null;
            }
            //  TipUtils.showTip("Oppo平台 创建插屏广告");
            this.interstitialAd = this.qg.createInsertAd({
                adUnitId: GameIdConfig.oppoID["InsertAdId"]
            });
            this.interstitialAd.load();
            this.interstitialAd.onLoad(() => {
                console.log('OPPOH5GameAPI InsertAd load success');
                //      TipUtils.showTip("插屏广告 下载成功 展示插屏广告");
                this.interstitialAd.show();
            });
            this.interstitialAd.onError((res) => {
                console.log('OPPOH5GameAPI InsertAd load Error:' + res);
                //     TipUtils.showTip("插屏广告 下载失败");
                this.interstitialAd.destroy();
                this.interstitialAd = null;
            });
            const onClose = (res) => {
                //  TipUtils.showTip("用户关闭插屏广告并销毁");
                this.interstitialAd.offClose(onClose);
                this.interstitialAd.destroy();
                this.interstitialAd = null;
            };
            this.interstitialAd.onClose(onClose);
        }

        console.log("oppoH5GameAPI showInsertAd");
    }
    /**创建原生 */
    createNativeAd() {

    }
    /**展示原生广告 */
    showNativeAd(id: string , callBack: Function) {
        if(!this.isShowNative) {
            console.log('oppo 一分钟原生广告冷却');
            return;
        }
        let currentTime:number=new Date().getTime();
        if(currentTime-InsManager.GetInstance()._DataSave.adRecordTime<=60000){
            return;
        }
        if(id == '' || id == null  || id ==undefined ){console.log("======" , id);   return;  } 
        if(this.qg){
            if (this.nativeAd == null) {
                this.nativeAd = this.qg.createNativeAd({
                    adUnitId: id
                });
            }
            this.nativeAd.load();
            const loadNative: Function = (res) => {
                console.log("原生广告加载", res.adList[0]);
                // if (res.adList[0] != undefined) {
                //     localStorage.setItem("NativeData", JSON.stringify(res.adList[0]));
                // }
                if (res && res.adList && res.adList[0] != undefined) {
                    this.resTemp = null;
                    this.resTemp = res.adList[0];
                    console.log("原生广告资源:", res.adList[0].imgUrlList);
                    callBack && callBack(res.adList[0] , this.nativeAd );
                }
    
                // let nativeData = JSON.parse(localStorage.getItem("NativeData"));
                // console.log("进入广告赋值" + nativeData);
                //上报广告曝光
                this.nativeAd.reportAdShow({
                    adId: res.adList[0].adId
                });
    
                this.nativeAd.offLoad(loadNative);
            };
    
            this.nativeAd.onLoad(loadNative);
    
            this.nativeAd.onError((err) => {
               if(InsManager.GetInstance()._DataSave.isDebug) InsManager.GetInstance()._UIManager.ShowGameToast('原生错误码：' + err.errCode , ToastType.Game  );
                console.log("原生错误========", err.errCode , err.errMsg);
    
                //   this.showInsertAd();
            });
        }
        
        console.log("Show NativeAd:" , '-'+id+'-');
    }
    /**原生被点击 */
    onNativeAdClick(_id: string) {
        if (this.nativeAd) {
            this.nativeAd.reportAdClick({
                adId: _id
            });
            console.log("点击原生三图广告：" , _id);
        }
    }
    /**创建原生icon */
    createNativeIconAd() {

    }
    /**展示原生icon */
    showNativeIconAd(id: string , callBack: Function) {
        if(!this.isShowNative) {
            console.log('oppo 一分钟原生广告冷却');
            return;
        }
        if(this.qg){
            if (this.nativeIconAd == null) {
                this.nativeIconAd = this.qg.createNativeAd({
                    adUnitId: id
                });
            }
            this.nativeIconAd.load();

            const loadNative: Function = (res) => {
                console.log("原生icon广告加载======", res.adList[0].icon);

                if (res && res.adList && res.adList[0] != undefined) {
                    this.resIconTemp = null;
                    this.resIconTemp = res.adList[0];
                    console.log("原生Icon 资源是又有的=====:" + res.adList[0].icon);
                    callBack && callBack(res.adList[0] , this.nativeIconAd);
                }

                //上报广告曝光
                this.nativeIconAd.reportAdShow({
                    adId: res.adList[0].adId
                });

                this.nativeIconAd.offLoad(loadNative);
            };

            this.nativeIconAd.onLoad(loadNative);

            this.nativeIconAd.onError((err) => {
                console.log("原生icon错误=======", err.errCode + "errMsg:" + err.errMsg);
                //   this.showInsertAd();
            });
        }
        console.log("Show NativeAd_Icon: " , '-' + id + '-');
    }
    /**原生icon被点击 */
    onNativeIconAdClick(_id: string) {
        if (this.nativeIconAd) {
            this.nativeIconAd.reportAdClick({ adId: _id });
        }
    }
    /**适配不同渠道存储键值对localstorage
     * 默认使用 localStorage
     */
    saveDataToCache(_key: string, _value: any) {

    }
    /**适配不同渠道读取键值对localstorage
     * 默认使用 localStorage
     */
    readDataFromCache(_key: string) {
        
    }
    /**添加icon到桌面 */
    addDesktop(_callback: Function) {
        if (this.qg != null && this.qg != undefined) {
            if (this.systemInfo.platformVersionCode < 1044) {
                console.log("版本号过低 无法创建桌面图标");
                return;
            }
            this.qg.hasShortcutInstalled({
                success: (res) => {
                    // 判断图标未存在时，创建图标
                    if (res == false) {
                        this.qg.installShortcut({
                            success: () => {
                                setTimeout(() => {
                                    this.qg.hasShortcutInstalled({
                                        success: (res) => {
                                            if (res == false) {
                                                _callback && _callback(false);
                                                console.log("============>:取消创建桌面图标");
                                            } else {
                                                _callback && _callback(true);
                                                console.log("============>:成功创建桌面图标");
                                            }
                                        }
                                    });
                                }, 500);
                            }
                        });
                    } else {
                        console.log("存在图标");
                    }
                },
                fail: (err) => { },
                complete: () => { }
            })
        }
    }

    public getDestTop(_callback: Function) {
        if(this.qg){
            this.qg.hasShortcutInstalled({
                success: (res) => {
                    if (res == false) {
                        _callback && _callback(false);
                        console.log("============>:没有图标");
                    } else {
                        _callback && _callback(true);
                        console.log("============>:有桌面图标");
                    }
    
                }
            });
        }
    }


    /**震动 */
    public PlayShock() {
       if(this.qg){
            this.qg.vibrateShort({
                success: function (res) { console.log("震动成功"); },
                fail: function (res) { console.log(`vibrateShort调用失败`); },
                complete: function (res) { }
            })
       }


    }

    /**开始录制视频 */
    startRecordScreen() {

    }
    /**结束录制视频 */
    stopRecordScreen() {

    }
    /**创建更多游戏按钮 */
    createMoreGamesBtn() {

    }
    /**展示更多游戏按钮   渠道互推盒子广告 */
    showMoreGamesBtn() {

        if(this.qg){
            // this.qg.navigateToMiniGame({
            //     pkgName: GameIdConfig.oppoMoreGameIDArr[Platforms.getInstance().oppoMoreGameIndex],
            //     success: function() {},
            //     fail: function(res) {
            //       console.log(JSON.stringify(res))
            //     }
            // });
            if(this.systemInfo.platformVersionCode<1076){
                console.log('快应用平台版本号低于1076，暂不支持互推盒子相关 API')
                return;
            }
            if(this.gamePortalAd){
                this.gamePortalAd.destroy();
                this.gamePortalAd=null;
            }
            this.gamePortalAd=this.qg.createGamePortalAd({
                adUnitId: GameIdConfig.oppoID["gamePortalAdID"]
            });
            this.gamePortalAd.load();
            this.gamePortalAd.onLoad(()=>{
                console.log("互推盒子九宫格加载成功显示");
                this.gamePortalAd.show();
            });
            let closeCallBack=()=>{
                 console.log("用户关闭九宫格盒子广告");
                 this.gamePortalAd.offClose(closeCallBack);
            };
            this.gamePortalAd.onClose(closeCallBack);
            this.gamePortalAd.onError((err)=>{
                console.log("九宫格盒子广告出现错误"+err.errCode + ',' + err.errMsg);
            });
        }
        // console.log('跳转到游戏：' ,  Platforms.getInstance().oppoMoreGameIndex);
    }
    /**
 * 跳转游戏
 * @param _packageName 包名
 */
    jumpToGame(_packageName: string) {
        if (this.qg !== null && this.qg !== undefined) {
            let obj = { pkgName: _packageName };
            console.log("oppoH5GameAPI=============================jumpToGame>:", _packageName);
            this.qg.navigateToMiniGame(obj);
        }

    }

    /** 数据打点 */
    ReportAnalytics(eventName: string, data: object) {
  
    }

    /** 添加彩签*/
    addColorBookmark() { 

    }
    /**订阅app */
    addSubscribeApp() {

    }
}