import { PlatformsAPI } from "./PlatformsAPI";
import oppoH5GameAPI from "./oppoH5GameAPI/oppoH5GameAPI";
import { VivoH5GameAPI } from "./VivoH5GameAPI/VivoH5GameAPI";
import AndroidGameAPI from "./AndroidGameAPI/AndroidGameAPI";

export enum Platform {
    baidu_H5 = 1,
    oppo_H5,
    qqplay_H5,
    toutiao_H5,
    vivo_H5,
    huawei_H5,
    weixin_H5,
    x4399_H5,
    xiaomi_H5,
    android,
    ios,
}
export default class Platforms {

    private static mInstance: Platforms = null;
    /** 是否直接获得奖励 开启之后会直接调用视频激励成功回调函数 */
    public isDirectGetAward = false;

    public isHasRecord = false; // 是否有录屏存在
    /**是否能够重新录制视频  */
    public isTakeRecordVideo: boolean = true; 

    /** 更多游戏下标 */
    public oppoMoreGameIndex: number = 0;

    private platformAPI: PlatformsAPI = null;


    /** 发布之前修改渠道 */
    public platform: Platform = Platform.vivo_H5;

    public static getInstance(): Platforms {
        if (this.mInstance === null) {
            this.mInstance = new Platforms();
        }
        return this.mInstance;
    }
    private constructor(){ }
    public onInit(_callback: Function) {
        switch (this.platform) {
            case Platform.oppo_H5: this.platformAPI = new oppoH5GameAPI();  break;
            case Platform.vivo_H5: this.platformAPI = new VivoH5GameAPI();  break;
            case Platform.android: this.platformAPI = new AndroidGameAPI();  break;
        }
        if (this.platformAPI && this.platformAPI !== null) {
            this.platformAPI.onInit(_callback);
        }
    }

    public onLogin() {
        this.platformAPI && this.platformAPI.onLogin();
    }
    public onShare(_success:Function) {
        this.platformAPI && this.platformAPI.onShare(_success);
    }
    public createBanner(id: string) {
        this.platformAPI && this.platformAPI.createBanner(id);
    }
    public showBanner(id: string) {
        this.platformAPI && this.platformAPI.showBanner(id);
    }
    public hideBanner() {
        this.platformAPI && this.platformAPI.hideBanner();
    }
    public createVideo(id: string , callBack: Function) {
        this.platformAPI && this.platformAPI.createVideo(id , callBack);
    }
    public showVideo(id: string , _successCallback?: Function, _failCallback?: Function) {
        this.platformAPI && this.platformAPI.showVideo(id ,  () => {
            _successCallback && _successCallback();
        }, () => {
            _failCallback && _failCallback();
        });
        if(this.isDirectGetAward){ _successCallback && _successCallback(); console.log('展示渠道视频广告');  }
    }
    public showVideoAward() {
        this.platformAPI && this.platformAPI.showVideoAward();
    }
    public showVideoFail() {
        this.platformAPI && this.platformAPI.showVideoFail();
    }
    public createInsertAd() {
        this.platformAPI && this.platformAPI.createInsertAd();
    }
    public showInsertAd() {
        this.platformAPI && this.platformAPI.showInsertAd();
    }
    public createNativeAd() {
        this.platformAPI && this.platformAPI.createNativeAd();
    }
    public showNativeAd(id: string , callBack: Function) {
        this.platformAPI && this.platformAPI.showNativeAd(id , callBack);
    }
    public onNativeAdClick(_id: string) {
        this.platformAPI && this.platformAPI.onNativeAdClick(_id);
    }
    public createNativeIconAd() {
        this.platformAPI && this.platformAPI.createNativeIconAd();
    }
    public showNativeIconAd(id: string , callBack: Function ) {
        this.platformAPI && this.platformAPI.showNativeIconAd(id , callBack);
    }
    public onNativeIconAdClick(_id: string) {
        this.platformAPI && this.platformAPI.onNativeIconAdClick(_id);
    }
    public saveDataToCache(_key: string, _value: any) {
        this.platformAPI && this.platformAPI.saveDataToCache(_key, _value);
    }
    public readDataFromCache(_key: string) {
        this.platformAPI && this.platformAPI.readDataFromCache(_key);
    }
    public addDesktop(_callback: Function) {
        this.platformAPI && this.platformAPI.addDesktop(_callback);
    }
    public getDestTop(_callback: Function) {
        this.platformAPI && this.platformAPI.getDestTop(_callback);
    }
    /**检测桌面图标i */

    public onShareVideo(_callback: Function) {
        this.platformAPI && this.platformAPI.onShareVideo(_callback);
    }
    public startRecordScreen() {
        this.platformAPI && this.platformAPI.startRecordScreen();
    }
    public stopRecordScreen() {
        this.platformAPI && this.platformAPI.stopRecordScreen();
    }
    public createMoreGamesBtn() {
        this.platformAPI && this.platformAPI.createMoreGamesBtn();
    }
    public showMoreGamesBtn() {
        this.platformAPI && this.platformAPI.showMoreGamesBtn();
    }
    public jumpToGame(_packageName: string) {
        this.platformAPI && this.platformAPI.jumpToGame(_packageName);
    }
    public addColorBookmark() {
        this.platformAPI && this.platformAPI.addColorBookmark();
    }
    public addSubscribeApp() {
        this.platformAPI && this.platformAPI.addSubscribeApp();
    }
  
    /**震动 */
    public PlayShock() {
        this.platformAPI && this.platformAPI.PlayShock();
    }
        /** 数据打点上传 */
    ReportAnalytics(eventName: string, data: object){
        if(this.isToutiao()){
            this.platformAPI && this.platformAPI.ReportAnalytics(eventName, data);
        }
    }


    //------------styles-------------
    /**区分渠道 */
    public isOppo() {
        let arr = [Platform.oppo_H5];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] === this.platform) {
                return true;
            }
        }
        return false;
    }
    public isVivo() {
        let arr = [Platform.vivo_H5];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] == this.platform) {
               // console.log("=====:" , arr[i] , this.platform);
                return true;
            }
        }
        return false;
    }
    public isHuaWei() {
        let arr = [Platform.huawei_H5];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] == this.platform) {
               // console.log("=====:" , arr[i] , this.platform);
                return true;
            }
        }
        return false;
    }
    public isToutiao() {
        let arr = [Platform.toutiao_H5];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] === this.platform) {
                return true;
            }
        }
        return false;
    }
    public isQQplay() {
        let arr = [Platform.qqplay_H5];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] === this.platform) {
                return true;
            }
        }
        return false;
    }

    public isAndroid() {
        let arr = [Platform.android];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] === this.platform) {
                return true;
            }
        }
        return false;
    }

    public isIos() {
        let arr = [Platform.ios];
        for (let i = 0; i < arr.length; ++i) {
            if (arr[i] === this.platform) {
                return true;
            }
        }
        return false;
    }

}