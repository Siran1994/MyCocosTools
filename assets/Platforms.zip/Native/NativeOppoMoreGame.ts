import Platforms from "../Platforms";

export default class NativeOppoMoreGame extends Laya.Script{
    constructor(){ super() }

    private icon: Laya.Image = null;
    private timeLoopFunc: Function = null;
    private index: number = 0;

    onAwake(): void{
        this.icon = this.owner as Laya.Image;
        if(Platforms.getInstance().isOppo() ) this.icon.visible = false;
        else this.icon.visible = false;


    }

    onEnable(){
        this.icon.on(Laya.Event.CLICK , this , ()=>{Platforms.getInstance().showMoreGamesBtn() } );
        this.icon.skin  = 'https://www.zywxgames.com/Resource/hujiazhi/EndSurvival/oppoGames11_30/' + this.index + '.png'
        Platforms.getInstance().oppoMoreGameIndex = this.index ;
        Laya.timer.loop(8000 , this , this.CarouselLoop);
    }


    /** icon 轮播循环 */
    private CarouselLoop(): void{
       this.index++;
       if(this.index > 9 )this.index = 0;
       this.icon.skin  = 'https://www.zywxgames.com/Resource/hujiazhi/EndSurvival/oppoGames11_30/' + this.index + '.png'
       Platforms.getInstance().oppoMoreGameIndex = this.index ;
    }


    onDisable(): void{
        Laya.timer.clear(this , this.CarouselLoop);
        this.icon.offAll(Laya.Event.CLICK);

    }

}