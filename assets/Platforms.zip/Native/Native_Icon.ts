import Platforms from "../Platforms"
import GameIdConfig from "../GameIdConfig";
import GameSystemData from "../../data/GameSystemData";
import InsManager from "../../manager/InsManager";

export default class Native_Icon extends Laya.Script{
 /** @prop {name:_id, tips:"广告ID", type:string, default:""}*/
    constructor(){ super()}

    public _id: string = null

    private cell: Laya.Image = null;
    private img: Laya.Image = null;

    onAwake(): void{
        this.cell = this.owner as Laya.Image;
        this.img = this.cell.getChildByName("img") as Laya.Image;
    }

    onEnable(): void{
        this.cell.visible  = false;
        if(!InsManager.GetInstance()._DataSave.isOpenAd || !Platforms.getInstance().isOppo() || GameSystemData.GetInstance().guide_step < 6) return;
        this.InitView();
    }

    public InitView(): void{

        // switch (this._id) {
        //     case GameIdConfig.oppoID.Award_Native_Icon_ID:
        //          this.img = this.cell.getChildByName("item").getChildByName("img_k").getChildByName("img") as Laya.Image;
        //         break;
        
        //     default: break;
        // }

        if(this._id == null){ return; }

        if(this._id == "") {
            console.log("没有传入正确的id");
            return;
        }
        let self = this;
        Platforms.getInstance().showNativeIconAd(this._id , (res , nativeIconAd)=>{
            //console.log("看看RES 是什么222？" , res.icon);
             if(res.icon != null && res.icon != undefined && res.icon != ""){
                self.img.skin = res.icon;
                this.cell.visible  = true;
                self.cell.on(Laya.Event.CLICK , this , ()=>{
                   // console.log("点击1111");
                    if (nativeIconAd) {
                        //console.log("点击2222");
                        nativeIconAd.reportAdClick({ adId: res.adId });
                    }
                });
             }else{
                 this.cell.visible = false;
                 console.log("没有找到原生Icon 资源");
             }

        });

    }

    onDisable(): void{
        this.cell.offAll(Laya.Event.CLICK)
    }


}