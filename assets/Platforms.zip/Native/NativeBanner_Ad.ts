import Platforms from "../Platforms";
import InsManager from "../../manager/InsManager";
import GameSystemData from "../../data/GameSystemData";


export default class NativeBanner_Ad extends Laya.Script{
 /** @prop {name:_id, tips:"广告ID", type:string, default:""}*/
 constructor(){ super()}

 public _id: string = "";

 private cell: Laya.Image = null;
 private img: Laya.Image = null;
 private close_bt:Laya.Sprite=null;
 private adClick_bt:Laya.Image=null;
 private index: number = 0;
 private guideImitNum:number=6;

 onAwake(): void{
     this.cell = this.owner as Laya.Image;
     this.img = this.cell.getChildByName("img") as Laya.Image;
     this.close_bt=this.cell.getChildByName("close_bt") as Laya.Sprite;
     this.adClick_bt=this.cell.getChildByName("close_bt") as Laya.Image;
 }

 onEnable(): void{
     this.cell.visible  = false;
     this.close_bt.on(Laya.Event.MOUSE_UP,this,this.closeBannerAd);
    
    //  if(HttpTakeNum.GetInstance().getGGType=="1"){
    //      this.guideImitNum=0;
    //  }else{
    //      this.guideImitNum=6;
    //  }
    
     console.log("banner广告是否到数了"+parseInt( Laya.LocalStorage.getItem("bannerHideCount")));
     if(!InsManager.GetInstance()._DataSave.isOpenAd || !Platforms.getInstance().isOppo() || GameSystemData.GetInstance().guide_step < 6||
     parseInt( Laya.LocalStorage.getItem("bannerHideCount")) >= 5) return;
     this.InitView();
 }
 private InitView(): void{

    
   
     if(this._id == "" || this._id == null || this.id == undefined) { console.log("没有传入正确的id");  return ; }

     let self = this;
     Platforms.getInstance().showNativeAd(this._id , (res , nativeAd)=>{
        // console.log("广告 资源：" , res);
          if(res.imgUrlList != null && res.imgUrlList != undefined && res.imgUrlList.length > 0){
             Platforms.getInstance().hideBanner();
             self.img.skin = res.imgUrlList[0];
             this.cell.visible  = true;

             console.log("轮播长度" + res.imgUrlList);

             Laya.timer.loop(500 , self , ()=>{
                self.index ++;
                if(self.index >= res.imgUrlList.length)  self.index = 0;
                self.img.skin = res.imgUrlList[self.index];
             })

             self.cell.on(Laya.Event.CLICK , this , ()=>{
                 if (nativeAd) {
                    nativeAd.reportAdClick({ adId: res.adId });
                 }
             });
             if(self.adClick_bt){
                self.adClick_bt.on(Laya.Event.CLICK , this , ()=>{
                  if (nativeAd) {
                     nativeAd.reportAdClick({ adId: res.adId });
                  }
              });
             }
          }else if(res.icon != null && res.icon != undefined && res.icon != "" ){
             Platforms.getInstance().hideBanner();
             self.img.skin = res.icon;
             this.cell.visible  = true;
             self.cell.on(Laya.Event.CLICK , this , ()=>{
                if (nativeAd) {
                   nativeAd.reportAdClick({ adId: res.adId });
                }
            });
            console.log('icon' , res.icon);
          }else{
            this.cell.visible = false;
            console.log("没有找到原生 广告 资源：" , res);
          }
     });
 }

 private closeBannerAd(){
    this.cell.visible=false;
    Laya.LocalStorage.setItem("bannerHideCount" , (parseInt( Laya.LocalStorage.getItem("bannerHideCount")) + 1).toString() );
    console.log("手动隐藏Banner:" +  Laya.LocalStorage.getItem("bannerHideCount"));
 }
  
  onDisable(): void{
    Laya.timer.clearAll(this);
    if(this.cell) this.cell.offAll(Laya.Event.CLICK);
  }
}