import GameConfig from "../../../GameConfig";
import { KpOpenType, ToastType } from "../../data/GameData";
import GameSystemData from "../../data/GameSystemData";
import { PathData } from "../../data/PathData";
import PropData from "../../data/PropData";
import InsManager from "../../manager/InsManager";
import RewardsManager from "../../manager/RewardsManager";
import SoundsManager from "../../manager/SoundsManager";
import VivoNativeAdPanel_Ctrl from "../../ui/VivoNativeAdPanel_Ctrl";
import GameIdConfig from "../GameIdConfig";
import { PlatformsAPI } from "../PlatformsAPI";


export  class VivoH5GameAPI implements PlatformsAPI{
    videoType: string;
    arg: any;

    //gameObject:Laya.Sprite3D = new Laya.Sprite3D();
    //game =null; //this.gameObject.addComponent(Game) as Game;
    private m_bannerAd:any = null;
    private m_videoAd:any = null;
    private m_insertAd:any = null;
    private m_nativeAd:any = null;
    private m_pInfo:number = 0;
    private m_qgInstance:any = null;

    private m_videoAdIsLoaded:boolean = false;
    private m_videoSuccessBack:Function = null;
    private m_videoFailBack:Function = null;
    private m_videoErrorBack:Function = null;
    private qg: any = window['qg'];

    private nativeDelay: number = 0; 
    private bannerDelay: number = 0; 

    /** 插屏是否延迟 */
    private isInsertDelay: boolean = false;

    private pack_Name = 'com.sscx.mrsc.vivominigame';
    private app_ID = '100009714';
    private Media_ID = '8880edd7fa84456aa72a4c08929292bf'
    private video_ID: string = '0e10c830245a4340806535cdd238220b';
    private nativeAd_ID: string = 'c55eef974b1f4c61aebac7f8c3f44532';
    private banner_ID: string = '6e27d54f18a9435c96db8fbe6839e827';
    private insert_ID: string = '99c6fc24d18748fba94a1c0db7ce9bd8';
    private nativeIcon_ID: string = '02546ce2172b4a36923584cae8bf71ec';

    private resTemp:any = null;
    /**获取屏幕宽高 */
    getScreenSize():Laya.Size
    {
        return new Laya.Size(1280,720);
    }
    /**初始化 */
    onInit(_callback:Function)
    {
        _callback && _callback();
    }
    /**登录 */
    onLogin()
    {
        if(!this.qg)
            this.qg = window['qg'];
        if(!this.qg) return;
        this.qg.getSystemInfo({
            success: (data)=>{
                this.m_pInfo = data.platformVersionCode;
                this.createVideo(this.video_ID , null);
            }
          });

        console.log('VivoH5GameAPI onLogin' , this.qg);
    }
    /**分享 */
    onShare()
    {
        //console.log('VivoH5GameAPI onShare');
    }
    /**上传最高分(排行榜) */
    updateHighScore(_score:number)
    {
        //console.log('VivoH5GameAPI updateHighScore');
    }
    /**初始化Ad (部分渠道需要先初始化广告 如oppo)*/
    onInitAdService()
    {
        //console.log('VivoH5GameAPI onInitAdService');
    }
    /**创建广告 BannerAd */
    createBanner(style: string)
    {
        this.hideBanner(); // 创建之前先清除 一下之前的
        if(this.qg){
            if(style == '0'){
                this.m_bannerAd = this.qg.createBannerAd({
                    posId: this.banner_ID,
                    style: {},

                });
                console.log('style:' ,this.m_bannerAd);
            }else {
              //  console.log('创建在上边的banner ');
                this.m_bannerAd = this.qg.createBannerAd({
                    posId: this.banner_ID,
                    style: {left: GameConfig.width/2 , top: -150},
                });
            }

            console.log('VivoH5GameAPI createBannerAd');
        }
        
    }
    /**展示Banner广告
     * 0 默认底部居中
     * 1 上边 可能是 0 0 位置显示
     */
    showBanner(style: string)
    {

        if(this.bannerDelay > 0){
            console.log('banner广告冷却中');
            return;
         }

        if(this.m_pInfo <1031)
        {
            console.log("Platform 不支持banner 展示 " + this.m_pInfo.toString());
            return ;
        }    

        this.createBanner(style);

        if(this.m_bannerAd)
        {
            this.m_bannerAd.show && this.m_bannerAd.show();
            this.m_bannerAd.onLoad(()=>{
                this.m_bannerAd.show();
                
                this.bannerDelay = 10; // 控制banner 冷却
                Laya.timer.once(this.bannerDelay * 1000 , this , ()=>{ this.bannerDelay = 0 } );

                console.log("VivoH5GameAPI onShowBanner Success");
            });
            this.m_bannerAd.onError((err)=>{
                console.log("VivoH5GameAPI Banner错误码： " + err.errCode);
            });
        }
        console.log("Show vivo Banner Ad");
    }
    /**隐藏Banner广告 */
    hideBanner()
    {
        if(this.m_bannerAd)
        {
            this.m_bannerAd.destroy();
            this.m_bannerAd = null;
            console.log('VivoH5GameAPI onHideBanner');
        }   
        console.log("Show Hide Banner Ad");
    }
    /**创建激励视频广告 RewardedVideoAd */
    createVideo(id: string , callBack: Function )
    {
        if(this.m_pInfo < 1041)
        {
            console.log("Platform " + this.m_pInfo.toString());
            return ;
        }
        if(this.qg)
        {

            if(this.m_videoAd) this.m_videoAd = null;

            this.m_videoAd = this.qg.createRewardedVideoAd({
                posId: this.video_ID
            });
            if(this.m_videoAd)
            {
                this.m_videoAd.onLoad(()=>{
                    this.m_videoAdIsLoaded = true;
                    console.log("VivoH5GameAPI onShowRewardedVideo Loaded");
                });
                this.m_videoAd.onError((err)=>{
                    this.m_videoErrorBack && this.m_videoErrorBack();
                    Laya.timer.once(60000,this,()=>{
                        this.m_videoAd.load();
                    }) 
                    console.log("VivoH5GameAPI onShowRewardedVideo Fail " , err.errCode , err.errMsg);
                });
                
               
                this.m_videoAdIsLoaded = true;
            }
            
        }
        console.log('VivoH5GameAPI createRewardedVideoAd');
    }
    /**展示RewardedVideo激励视频广告 */
    showVideo(_id: string ,  _successCallback:Function , _failCallback:Function)
    {      
        if(this.m_pInfo < 1041)
        {
            console.log("Platform 不支持视频广告 " + this.m_pInfo.toString());
            return ;
        }

        //this.createVideo(this.video_ID , null);

        this.m_videoSuccessBack = _successCallback;
        this.m_videoFailBack = _failCallback;
        this.m_videoErrorBack = this.m_videoErrorBack;
        if(this.m_videoAd)
        {
                        
            const onClose = (res)=>{
                if(res && res.isEnded)
                {
                    this.m_videoAdIsLoaded = false;
                    this.m_videoSuccessBack && this.m_videoSuccessBack();
                    console.log('视频成功回调奖励');
                    Laya.timer.once(1000,this,()=>{
                        this.m_videoAd.load();
                    }) 
                    console.log("VivoH5GameAPI onShowRewardedVideo Success");
                }
                else
                {
                    this.m_videoAdIsLoaded = false;
                    this.m_videoFailBack && this.m_videoFailBack()
                    Laya.timer.once(1000,this,()=>{
                        this.m_videoAd.load();
                    }) 
                    InsManager.GetInstance()._UIManager.ShowGameToast('未完整观看视频无法获得奖励' , ToastType.Game);
                    console.log("VivoH5GameAPI onShowRewardedVideo Cancel");
                }
                Laya.SoundManager.setMusicVolume(0.35) ;
                this.m_videoAd.offClose(onClose);
            }

            this.m_videoAd.onClose(onClose);

            if(this.m_videoAdIsLoaded)
            {
                Laya.timer.once(200,this,()=>{
                    if(RewardsManager.GetInstance().isShowKnapsackPanel) InsManager.GetInstance()._UIManager.ShowKnapsackPanel( KpOpenType.EquipmentList , InsManager.GetInstance()._knapsackManager.FindKnapsackData(PathData.Knapsack_EquipmentColumn ,  PropData.GetInstance().knapsackData).id , PropData.GetInstance().knapsackData);
                    this.m_videoAd.show();
                    Laya.SoundManager.setMusicVolume(0) ;
                });
                InsManager.GetInstance()._UIManager.ShowGameToast('完整观看视频才能获得奖励' , ToastType.Game);
            }
            else
            {
                InsManager.GetInstance()._UIManager.ShowGameToast('视频还没准备好！稍候再试试吧！' , ToastType.Game);
            }
        }
        console.log("VivoH5GameAPI onShowRewardedVideo:" , this.video_ID);
    }
    /**创建插屏广告 createInsertAd */
    createInsertAd()
    {
        if(this.qg)
        {
            this.m_insertAd = this.qg.createInterstitialAd({
                posId: this.insert_ID
            });
        }
        console.log('VivoH5GameAPI createInsertAd');
    }
    /**展示InsertAd插屏广告 */
    showInsertAd()
    {

        if(this.isInsertDelay || GameSystemData.GetInstance().guide_step < 6 ){console.log('插屏冷却中~'); return; }

        if(this.m_pInfo < 1031)
        {
            console.log("Platform 不支持插屏" + this.m_pInfo.toString());
            return ;
        }
        this.createInsertAd();
        console.log('VivoH5GameAPI onShowInsertAd');
        if(this.m_insertAd)
        {
            // this.m_insertAd.onLoad(()=>{
            //     this.m_insertAd.show();
            //     console.log("VivoH5GameAPI onShowInsertAd Loaded");
            // });
            this.m_insertAd.onError((err)=>{
                console.log("VivoH5GameAPI onShowInsertAd " + err.errCode)
            });
            let nInsert = this.m_insertAd.show();
            let self = this;
            nInsert && nInsert.then(()=>{
                self.isInsertDelay = true;
                Laya.timer.once(60000 , this ,()=>{  self.isInsertDelay = false; });
                console.log("VivoH5GameAPI onShowInsertAd Suceess");
            }).catch((err)=>{
                this.m_insertAd.load().then(()=>{
                    this.m_insertAd.show();
                });
            });
        }
    }

    /**创建原生广告 createNativeAd */
    createNativeAd()
    {
        if(this.m_pInfo < 1053)
        {
            console.log("Platform " + this.m_pInfo.toString());
            return ;
        }
        this.m_nativeAd = this.qg.createNativeAd({
            posId: this.nativeAd_ID,
          });
        console.log('VivoH5GameAPI createNativeAd');
    }

    /**
     * 显示原生广告
     * @param _callback 回调函数
     */
    showNativeAd(_id: string , _callback:Function){

        if(this.nativeDelay > 0){
            console.log('原生广告冷却中');
            return;
         }

        if(this.m_pInfo < 1053)
        {
            console.log("Platform 太低不支持原生 " + this.m_pInfo.toString());
            return ;
        }

        this.createNativeAd();

        if(this.m_nativeAd){
            this.m_nativeAd.load();
            this.m_nativeAd.onLoad((res)=>{
                if(res && res.adList){
                    this.resTemp = res.adList[res.adList.length-1];
                    if(this.resTemp){
                        //Laya.timer.once(500,this,()=>{
                            _callback && _callback(this.resTemp);
                            console.log('vivo 原生' , this.resTemp );
                            this.m_nativeAd.reportAdShow({
                                adId: this.resTemp.adId,
                            });
                            Laya.timer.once(1000,this,()=>{
                                let vivoNativeAdPanel: VivoNativeAdPanel_Ctrl = InsManager.GetInstance()._UIManager.ShowUI(PathData.vivoNativeAdPanel).getComponent(VivoNativeAdPanel_Ctrl);
                                vivoNativeAdPanel.InitView(this.resTemp);
                            });
                           
        
                            this.nativeDelay = 10;
                            Laya.timer.once(this.nativeDelay * 1000 , this , ()=>{ this.nativeDelay = 0 } );
                            this.hideBanner();
                          
                          
                        //})
                    }else{
                       console.log('原生拉取失败');
                    }
                }
            });

            this.m_nativeAd.onError((err)=>{
                console.log("Native Error ======= "+ err.errCode);
               // Game_App._Instance.toastCtrl.OpenSet("Native Error "+ err.errCode);
            })

         
        }
        console.log('vivoH5GameAPI onShowNativeAd');
    }

    onNativeAdClick(_id:string){
        if(this.m_nativeAd){
            this.m_nativeAd.reportAdClick({
                adId:_id
            });
        }
        console.log('VivoH5GameAPI onNativeAdClick:'+ _id);
    }

    /**存储数据
     * @param _key 索引 string
     * @param _value 值
     * @param _IsNumber 是否为数值类型
     */
    saveDataToCache(_key:string,_value:any,_IsNumber?:boolean)
    {
        //this.qg.setStorage({key:_key,value:_value});
        localStorage.setItem(_key,_value);
    }

    /**震动 */
    onShake()
    {
        if(this.qg) this.qg.vibrateShort();
    }
    /**读取数据
     * @param _key 索引 string
     * @param _IsNumber 是否为数值类型
     */
    readDataFromCache(_key:string,_IsNumber?:boolean)
    {
        let ret;
        if(_IsNumber)
            ret = parseInt(localStorage.getItem(_key));
        else
            ret = localStorage.getItem(_key);
        return ret;
    }
    // onClick(){
    //     if(this.game.game_connect_err_UI.parent !== null && this.game.game_connect_err_UI.parent !== undefined){
    //         this.game.game_connect_err_UI.visible = false;
    //     }
    // }

        /** 数据打点 */
    ReportAnalytics(eventName: string, data: object) {
  
    }
    getGGTypeToCheck():number
    {
        return 1;
    }

    onShareVideo(_callback: Function) {
        throw new Error("Method not implemented.");
    }


    showVideoAward() {
        throw new Error("Method not implemented.");
    }
    showVideoFail() {
        throw new Error("Method not implemented.");
    }


    createNativeIconAd() {
        throw new Error("Method not implemented.");
    }
    showNativeIconAd(id: string, callBack: Function) {
        throw new Error("Method not implemented.");
    }
    onNativeIconAdClick(_id: string) {
        throw new Error("Method not implemented.");
    }
    addDesktop(_callback: Function) {
        if (this.qg != null && this.qg != undefined) {
            this.qg.hasShortcutInstalled({
                success: (res) => {
                    // 判断图标未存在时，创建图标
                    if (res == false) {
                        this.qg.installShortcut({
                            success: () => {
                                setTimeout(() => {
                                    this.qg.hasShortcutInstalled({
                                        success: (res) => {
                                            if (res == false) {
                                                _callback && _callback(false);
                                                console.log("============>:取消创建桌面图标");
                                            } else {
                                                _callback && _callback(true);
                                                console.log("============>:成功创建桌面图标");
                                            }
                                        }
                                    });
                                }, 500);
                            }
                        });
                    } else {
                        console.log("存在图标");
                    }
                },
                fail: (err) => { },
                complete: () => { }
            });

        }
    }
    

    getDestTop(_callback: Function) {
        if(this.qg){
            this.qg.hasShortcutInstalled({
                success: function(status) {
                  if(status) {
                    _callback && _callback(true);
                    console.log('已创建');
                  }else{
                    _callback && _callback(false);
                    console.log('未创建');
                  }
                }
            });
        }
    }

    startRecordScreen() {
        throw new Error("Method not implemented.");
    }
    stopRecordScreen() {
        throw new Error("Method not implemented.");
    }
    createMoreGamesBtn() {
        throw new Error("Method not implemented.");
    }
    showMoreGamesBtn() {
        throw new Error("Method not implemented.");
    }
    jumpToGame(_packageName: string) {
        throw new Error("Method not implemented.");
    }
    addColorBookmark() {
        throw new Error("Method not implemented.");
    }
    addSubscribeApp() {
        throw new Error("Method not implemented.");
    }
    PlayShock() {
        if(this.qg) { 
            this.qg.vibrateShort();
           // console.log('播放震动···········');
        }
    }
    /**录制 */
    startRecorder(){  }
    pauseRecorder(){  }
    resumeRecorder(){ }
    stopRecorder(){}
    onShowAppBox(){}
}
