export default  class  GameIdConfig{

    public static qqplayID:Object = {

    }
    public static toutiaoID:Object = {
        appId:"tt0cdb7a6693e3d90902",
        bannerAdId:"iwqqrbsn1b703fdg98",
        rewardedVideoAdId:"2g1j45nl0emlemfrss",
        InsertAdId:"108o3o2hkih1172iss",
        ShareID: "26dg96ged4lh1cbe3e",
    }
    public static vivoID:Object = {

    }

    public static oppoID = {
        gamePortalAdID:"291699",
    }

   /** oppo 更多游戏包名 */
    public static oppoMoreGameIDArr= [
        'com.tykj.hcgte3d.kyx.nearme.gamecenter',
        'com.zqx.dmxs.kyx.nearme.gamecenter',
        'com.zsfz.elsdz.net.nearme.gamecenter',
        'com.zqx.ltdzz.kyx.nearme.gamecenter',
        'com.szly.zzssyx.kyx.nearme.gamecenter',
        'com.mxcy.cqjsnjq.kyx.nearme.gamecenter',
        'com.mxcy.rlybdd2.kyx.nearme.gamecenter',
        'com.zsfz.hcrstt.kyx.nearme.gamecenter',
        'com.zsfz.wdjysq2.kyx.nearme.gamecenter',
        'com.zsfz.dycxy.kyx.nearme.gamecenter',
    ]

    



    public static weixinID:Object = {
        appId:"",
        bannerAdId:"",
        rewardedVideoAdId:"",
        InsertAdId:"",
        NativeAdId:"",
        NativeAdIconId:"",
    }

}
