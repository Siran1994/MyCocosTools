export interface PlatformsAPI {
    videoType: string;
    arg: any;
    /**初始化 */
    onInit(_callback: Function);
    /**登录*/
    onLogin();
    /**分享游戏 */
    onShare(_success:Function);
    /**分享录屏 */
    onShareVideo(_callback: Function);
    /**创建banner */
    createBanner(id: string);
    /**展示banner */
    showBanner(id: string);
    /**隐藏banner */
    hideBanner();
    /**创建激励视频 */
    createVideo(id: string , callBack: Function);
    /**
     * 
     * @param _type 类型
     * @param _arg 参数
     * @param _successCallback 成功回调
     * @param _failCallback 失败回调
     */
    /**展示激励视频 */
    showVideo(id: string , _successCallback?: Function, _failCallback?: Function);
    /**----------原生平台调用----------
     * 激励视频播放成功后调用(OC->TS || JAVA->TS) 
     */
    showVideoAward();
    /**----------原生平台调用----------
     * 激励视频播放失败后调用(OC->TS || JAVA->TS) 
     */
    showVideoFail();
    /**创建插屏 */
    createInsertAd();
    /**展示插屏 */
    showInsertAd();
    /**创建原生 */
    createNativeAd();
    /**展示原生 */
    showNativeAd(id: string , callBack: Function);
    /**原生被点击 */
    onNativeAdClick(_id: string);
    /**创建原生icon */
    createNativeIconAd();
    /**展示原生icon */
    showNativeIconAd(id: string , callBack: Function);
    /**原生icon被点击 */
    onNativeIconAdClick(_id: string);
    /**适配不同渠道存储键值对localstorage
     * 默认使用 localStorage
     */
    saveDataToCache(_key: string, _value: any);
    /**适配不同渠道读取键值对localstorage
     * 默认使用 localStorage
     */
    readDataFromCache(_key: string);
    /**添加icon到桌面 */
    addDesktop(_callback: Function);

    /**检测桌面图标i */
    getDestTop(_callback: Function);

    /**开始录制视频 */
    startRecordScreen();
    /**结束录制视频 */
    stopRecordScreen();
    /**创建更多游戏按钮 */
    createMoreGamesBtn();
    /**展示更多游戏按钮 */
    showMoreGamesBtn();
    /**
     * 跳转游戏
     * @param _packageName 包名
     */
    jumpToGame(_packageName: string);
    /** 添加彩签*/
    addColorBookmark();
    /**订阅app */
    addSubscribeApp();
    /** 数据打点上传 */
    ReportAnalytics(eventName: string, data: object);

    /**震动 */
    PlayShock();
}