import { PlatformsAPI } from "../PlatformsAPI";
import InsManager from "../../manager/InsManager";
import { ToastType } from "../../data/GameData";

export default class AndroidGameAPI implements PlatformsAPI{
    videoType: string = null;
    arg: any = null;

    bridge: any = null;


    /**初始化 */
    onInit(_callback:Function)
    {
        try {       
            this.bridge = window["PlatformClass"].createClass("com.zsfz.zhcz3.JSBridge"); // 记得更改成自己的包名
        } catch (error) {
            console.log(error);
        }

       if(this.bridge == null || this.bridge == undefined) console.error('平台未找到 bridge:' ,  this,this.bridge);
       this.getGGTypeFromPlatform();
        _callback && _callback();
    }
    /**登录 */
    onLogin()
    {
       
    }

    /** 获得广告策略参数数 */
    getGGTypeFromPlatform()
    {
        if(this,this.bridge){
            this.bridge.callWithBack((res)=> {
                let data = JSON.parse(res);
                this.gType = data.gType
                
                if(this.gType ==  1){
                    this.interDelayTime = 60000;
                }else if( this.gType == 2){
                    this.interDelayTime = 30000; 
                }else if(this.gType == 3 ){
                    this.interDelayTime = 1000;
                }else{
                    this.interDelayTime = 0;
                }
                // Game_App._Instance.toastCtrl.OpenSet("laya参数："+ this.gType);
                if(this.gType > 0 ){
                    InsManager.GetInstance()._DataSave.isOpenAd = true;
                    
                }else{
                    InsManager.GetInstance()._DataSave.isOpenAd = false;
                }
            },"getGGType");
        }
    }

    createBanner(id: string) { }
    /** 展示Banner 广告 */
    showBanner(id: string) {
        if(!InsManager.GetInstance()._DataSave.isOpenAd) return; // 报错就删
        console.log("show android banner ad");
        if(this.gType <= 0 ) return;
        if(this.bridge){
           this.bridge.call("showBanner");
        }  
    }
    hideBanner() { }

    createVideo(id: string, callBack: Function) {}

    showVideo(id: string, _successCallback?: Function, _failCallback?: Function) {
        console.log("show android rewardedvideo ad");
        if(this.gType <= 0) return;
        if(this.bridge){
            this.bridge.callWithBack((res)=> {
                let data = JSON.parse(res);
                switch(data.code)
                {
                    case "200":
                        console.log("video success");
                        _successCallback&&_successCallback();
                    break;
                    case "201":
                        console.log("video fail");
                        InsManager.GetInstance()._UIManager.ShowGameToast('视频播放失败，请稍后再试试' , ToastType.Game);
                    break;
                    case "202":
                        console.log("video close");
                        _failCallback&&_failCallback();
                          InsManager.GetInstance()._UIManager.ShowGameToast('中途退出无法获得奖励' , ToastType.Game);
                    break;
                    case "203":
                        InsManager.GetInstance()._UIManager.ShowGameToast('观看完整视频获得奖励' , ToastType.Game);
                        console.log("video show")
                        
                    break;
                }
            },"showVideo");
        }
    }

    showVideoAward() {
        throw new Error("Method not implemented.");
    }
    showVideoFail() {
        throw new Error("Method not implemented.");
    }

    /** 显示插屏 */
    showInsertAd() {
        if(this.gType <= 0  ) return;//广告策略
        if( this.bridge){
            this.bridge.call("showInsertAd"); //方法必须和Android 那边保持一致
            this.isInterDelay = true;
            Laya.timer.once(this.interDelayTime , this , this.SetInsterDelayTimer)
        }
    }
   
    private gType:number = 0;
    private isInterDelay: boolean = false; //插屏是否延迟
    private interDelayTime: number = 0; //插屏延迟时间


    /**获取屏幕宽高 */
    getScreenSize():Laya.Size
    {
        return new Laya.Size(1280,720);
    }
 

    /**上传最高分(排行榜) */
    updateHighScore(_score:number){}

    /**初始化Ad (部分渠道需要先初始化广告 如oppo)*/
    onInitAdService(){}
    /**创建广告 BannerAd */
    createBannerAd(){
      
    }
    /**展示Banner广告 */

    /**隐藏Banner广告 */
    onHideBanner(){}


    /**创建插屏广告 createInsertAd */
    createInsertAd(){}


    /** 获取广告策略值  必须初始化之后才有真确的值 */
    getGGTypeToCheck():number
    {
        console.log("laya 取得广告参数为：" + this.gType);
        return this.gType;
    }

    /**设置延迟结束 */
    private SetInsterDelayTimer(): void{
        this.isInterDelay = false;
    }

    moreGame(){
       if(this.bridge)  this.bridge.call("moreGame");  
    }


    /**分享 */
    onShare(){}
    createNativeAd() {
        // throw new Error("Method not implemented.");
     }
     showNativeAd(id: string, callBack: Function) {
       //  throw new Error("Method not implemented.");
     }
     onNativeAdClick(_id: string) {
       //  throw new Error("Method not implemented.");
     }
     createNativeIconAd() {
        // throw new Error("Method not implemented.");
     }
     showNativeIconAd(id: string, callBack: Function) {
        // throw new Error("Method not implemented.");
     }
     onNativeIconAdClick(_id: string) {
        // throw new Error("Method not implemented.");
     }
     addDesktop(_callback: Function) {
        // throw new Error("Method not implemented.");
     }
     getDestTop(_callback: Function) {
        // throw new Error("Method not implemented.");
     }
     startRecordScreen() {
         //throw new Error("Method not implemented.");
     }
     stopRecordScreen() {
         //throw new Error("Method not implemented.");
     }
     createMoreGamesBtn() {
        // throw new Error("Method not implemented.");
     }
     showMoreGamesBtn() {
         //throw new Error("Method not implemented.");
     }
     jumpToGame(_packageName: string) {
       //  throw new Error("Method not implemented.");
     }
     addColorBookmark() {
         //throw new Error("Method not implemented.");
     }
     addSubscribeApp() {
         //throw new Error("Method not implemented.");
     }
     ReportAnalytics(eventName: string, data: object) {
         //throw new Error("Method not implemented.");
     }
     /** 震动 */
     PlayShock() {
        if( this.bridge){
            this.bridge.call("PlayShock"); //方法必须和Android 那边保持一致
        }
     }
     onShareVideo(_callback: Function) {
        // throw new Error("Method not implemented.");
     }
     
    /**存储数据
     * @param _key 索引 string
     * @param _value 值
     * @param _IsNumber 是否为数值类型
     */
    saveDataToCache(_key:string,_value:any,_IsNumber?:boolean){
        Laya.LocalStorage.setItem(_key,_value);
    }
    /**读取数据
     * @param _key 索引 string
     * @param _IsNumber 是否为数值类型
     */
    readDataFromCache(_key:string,_IsNumber?:boolean){
        if(!_IsNumber)
            return Laya.LocalStorage.getItem(_key);
        else 
        {
            let num = parseInt(Laya.LocalStorage.getItem(_key));
            return num;
        }
    }

  
}
