import { PlatformsAPI } from "../PlatformsAPI";
import GameIdConfig from "../GameIdConfig";
import InsManager from "../../manager/InsManager";
import { KpOpenType, ToastType } from "../../data/GameData";
import Platforms from "../Platforms";
import EventManager from "../../manager/EventManager";
import { PathData } from "../../data/PathData";
import PropData from "../../data/PropData";
import RewardsManager from "../../manager/RewardsManager";


export default class toutiaoH5GameAPI implements PlatformsAPI {


    videoType: string;
    arg: any;

    /**平台环境 */
    tt: any = window["tt"];
    //  qg: any = window["qg"];
    /**banner广告 */
    bannerAd: any = null;
    /**插屏广告 */
    insertAd: any = null;
    /**视频广告 */
    rewardedVideoAd: any = null;
    /**视频广告是否已经load到数据 */
    m_videoAdIsLoaded: boolean = false;
    /**原生 */
    nativeAd: any = null;
    /**原生load取值 */
    resTemp: any = null;

    /**系统信息 */
    systemInfo: any = null;
    windowWidth: number = 0;
    windowHeight: number = 0;

    /**录屏 */
    recorder: any = null;
    //录屏时间
   // recordTime: number = 0;
    shareUrl: string = "https://www.zywxgames.com/Resource/zhangxinfei/XSJRSTProject/TT/share.jpg";
    /**录屏video地址 */
    videoPath: any = null;

    /**记录录屏时间戳 */
    private videoTimerTmp: number = 0;



    /**初始化 */
    onInit(_callback: Function) {
        _callback && _callback();
        if (this.tt != null && this.tt != undefined) {
            let res = this.tt.getSystemInfoSync();
            if (res) {
                this.windowWidth = res.windowWidth;
                this.windowHeight = res.windowHeight;
                this.systemInfo = res;
            }
            console.log(res);

            this.recorder = this.tt.getGameRecorderManager();

            this.createVideo();
            this.tt.onShow((res) => {
                console.log("============监听小游戏回到前台的事件============");
              //  AudioSoundManager.JAVAResumePayMusic();
              //  MessageEventManager._instance.DispatchEvent("BackToGameEvent");
            });

            this.tt.onHide(() => {
                console.log("============监听小游戏隐藏到后台事件=========")
                // SDKManager._instance.OutStage();
              //  MessageEventManager._instance.DispatchEvent("OutStageGameEvent");
              //  AudioSoundManager.JAVAPauseStopMusic();

            });


        }
        // this.createVideo();
        console.log("toutiaoH5GameAPI onInit");
    }

    getDestTop(_callback: Function) {
    }

    /**登录*/
    onLogin() {
    }

    /**分享游戏链接 */
    onShare(_callback: Function) {
    }


    /**开始录制视频 */
    startRecordScreen() {
      
        if(this.tt == null || this.tt == undefined) return;

        if(!Platforms.getInstance().isTakeRecordVideo ){ console.log('重复录屏阻断') ; return };
        Platforms.getInstance().isTakeRecordVideo = false;
        if (!this.recorder)
            this.recorder = this.tt.getGameRecorderManager();

        this.recorder.start({
            duration: 30
        });
        this.recorder.onStart(res => {
            this.videoTimerTmp = Date.now();
            EventManager._Instance.Dispatch_Event(PathData.EVENT_UPDATERECORDINGSTATE , true);
            console.log("=============头条开始录屏===============");

        });
        this.recorder.onStop(res => {
          //  this.recordTime = Date.now() - (this.videoTimerTmp + this.videoMinTimer);
            this.videoPath = res.videoPath;
            if(this.videoPath != null) Platforms.getInstance().isHasRecord = true;
            EventManager._Instance.Dispatch_Event(PathData.EVENT_UPDATERECORDINGSTATE , false);
            console.log("==========自动结束录屏===========", this.videoPath);
        });
        this.recorder.onError(res => {
           // this.recordTime = 0;
            console.log("========================>录屏失败:", res.errMsg);
        });
     
    }
    /**结束录制视频 */
    stopRecordScreen() {

        if (this.recorder) {
            console.log("手动结束视频录制");
            EventManager._Instance.Dispatch_Event(PathData.EVENT_UPDATERECORDINGSTATE , false);
            this.recorder.stop();
            this.recorder.onStop(res => {
              //  this.recordTime = Date.now() - (this.videoTimerTmp + this.videoMinTimer);
                this.videoPath = res.videoPath;
                if(this.videoPath != null) Platforms.getInstance().isHasRecord = true;
                InsManager.GetInstance()._UIManager.ShowUI(PathData.TTSharePanel); // 有录屏 点击弹出分享
                //console.log("手动结束录屏==========", this.recordTime, this.videoPath);
            });

        }
    }

    ShareVideoJudge(): boolean {
        if (this.recorder) {
           // if ((this.recordTime > this.videoMinTimer) && this.videoPath) {
                return true;
           // }
        } else {
            return false;
        }
    }

    /**分享录屏 */
    onShareVideo(_callback: Function) {
        if (this.tt != null && this.tt != undefined && this.videoPath != null) {
           
          //  if (this.recordTime < this.videoMinTimer) {
                //_callback && _callback();
             //   console.log('时间不够返回===');
               // return;
          //  }
            console.log("this.videoPath======", this.videoPath);
            let self = this;
            this.tt.shareAppMessage({
                channel: "video",
                title: "逃出荒岛大冒",
                extra: {
                    videoPath: this.videoPath, // 可用录屏得到的视频地址
                    videoTopics: ['一个人说走就走的冒险之旅']
                },
                success() {
                    Platforms.getInstance().isTakeRecordVideo = true // 可以录制新视频
                    _callback && _callback(1);
                    
                },
                fail(e) {
                    Platforms.getInstance().isTakeRecordVideo = true // 可以录制新视频
                    console.log('分享视频失败', e);
                    _callback && _callback(0);
                }
            });
        }else{
            InsManager.GetInstance()._UIManager.ShowGameToast('暂时没有录屏，请稍后再试试！' , ToastType.Game);
        }
        
        console.log("toutiaoH5GameAPI onShareVideo");
    }


    /**创建banner */
    createBanner(id: string ) {
        let targetBannerAdWidth = 138;
        this.bannerAd = null;
        if(id = '0'){
            //创建在下方的Banner
            this.bannerAd = this.tt.createBannerAd({
                adUnitId: GameIdConfig.toutiaoID["bannerAdId"],
                adIntervals: 30,
                style: {
                    width: targetBannerAdWidth,
                    left: (this.windowWidth - targetBannerAdWidth) / 2,
                    top: this.windowHeight - targetBannerAdWidth / 16 * 9, // 根据系统约定尺寸计算出广告高度
                }
            });
        }else{
            //创建在上方的Banner
            this.bannerAd = this.tt.createBannerAd({
                adUnitId: GameIdConfig.toutiaoID["bannerAdId"],
                adIntervals: 30,
                style: {
                    width: targetBannerAdWidth,
                    left: (this.windowWidth - targetBannerAdWidth) / 2,
                    top: this.windowHeight - 100, // 根据系统约定尺寸计算出广告高度
                }
            });
        }
        


        console.log("banner left top", targetBannerAdWidth, (this.windowWidth - targetBannerAdWidth) / 2, this.windowHeight - (targetBannerAdWidth / 16 * 9));
    }

    /**展示banner */
    showBanner(id: string) {
        // if (this.tt != null && this.tt != undefined) {

        //     if (this.systemInfo.appName == "Douyin") {//抖音屏蔽
        //         return;
        //     }
        //     this.hideBanner();

        //     this.createBanner(id);

        //     this.bannerAd.onLoad(() => {
        //         this.bannerAd.show().then(() => {
        //             console.log('show banner success');
        //         }).catch(err => {
        //             console.log('show banner fail ', err);

        //         });
        //     });

        //     let onResizeCallback = (size) => {
        //         console.log(size.width, size.height);
        //         this.bannerAd.style.top = this.windowHeight - size.height;
        //         this.bannerAd.style.left = (this.windowWidth - size.width) / 2;

        //         this.bannerAd.offResize(onResizeCallback);
        //     }
        //     this.bannerAd.onResize(onResizeCallback);
        // }
        // console.log("TT =>显示banner");
    }
    /**隐藏banner */
    hideBanner() {
       // console.log("隐藏banner");
        // if (this.bannerAd) {
        //     this.bannerAd.destroy();
        //     this.bannerAd = null;
        // }
    }
    /**创建激励视频 */
    createVideo() {
        if (this.tt != null && this.tt != undefined) {

            this.rewardedVideoAd = this.tt.createRewardedVideoAd({
                adUnitId: GameIdConfig.toutiaoID["rewardedVideoAdId"]
            });

            console.log("toutiaoH5GameAPI 创建激励视频", this.rewardedVideoAd);

            this.rewardedVideoAd.load().then(() => {
                console.log("广告加载成功");
                this.m_videoAdIsLoaded = true;
            }).catch((err) => {
                console.log("广告加载失败：" , err);
          //  InsManager.GetInstance()._UIManager.ShowGameToast("广告在加载中,请稍后再试试" , ToastType.Game);
                this.m_videoAdIsLoaded = false;
            });

        }
    }

    private isNoShowVideo: number = 0;
    /**
     * 
     * @param _type 类型
     * @param _arg 参数
     * @param _successCallback 成功回调
     * @param _failCallback 失败回调
     */
    /**展示激励视频 */
    showVideo(_type: string,  _successCallback?: Function, _failCallback?: Function) {
        this.videoType = _type;
        if (this.rewardedVideoAd && this.m_videoAdIsLoaded) {
           // Laya.timer.scale = 0;
            //if(InsManager.GetInstance()._SceneManager.player != null)InsManager.GetInstance()._SceneManager.player.isNpcAtk = false;

           if(RewardsManager.GetInstance().isShowKnapsackPanel) InsManager.GetInstance()._UIManager.ShowKnapsackPanel( KpOpenType.EquipmentList , InsManager.GetInstance()._knapsackManager.FindKnapsackData(PathData.Knapsack_EquipmentColumn ,  PropData.GetInstance().knapsackData).id , PropData.GetInstance().knapsackData);
          
            this.rewardedVideoAd.show().then(() => {
                console.log("广告显示成功");
              }).catch((err) => {
                console.error("广告组件出现问题", err);
                InsManager.GetInstance()._UIManager.ShowGameToast('广告组件出现问题' , ToastType.Game);
                // 可以手动加载一次
                _failCallback && _failCallback();
              });;

            this.isNoShowVideo = 0;

            const onCloseFunc = (res) => {
                if (res && res.isEnded) {
                    console.log("onClose正常播放结束，可以下发游戏奖励");
                    _successCallback && _successCallback();
                   // if(InsManager.GetInstance()._SceneManager.player != null)InsManager.GetInstance()._SceneManager.player.isNpcAtk = true;
                   // Laya.timer.scale = 1;
                   
                    //重新加载视频
                    this.rewardedVideoAd.load().then(() => {
                        console.log("广告加载成功");
                        this.m_videoAdIsLoaded = true;
                    }).catch((err) => {
                        console.log("加载视频失败");
                        this.m_videoAdIsLoaded = false;
                    });
                } else {
                    InsManager.GetInstance()._UIManager.ShowGameToast("未完整看完视频无法获得奖励" , ToastType.Game);
                   // if(InsManager.GetInstance()._SceneManager.player != null)InsManager.GetInstance()._SceneManager.player.isNpcAtk = true;
                  //  Laya.timer.scale = 1;
                    console.log("onClose播放中途退出，不下发游戏奖励");

                    _failCallback && _failCallback();

                    //重新加载视频
                    this.rewardedVideoAd.load().then(() => {
                        console.log("广告加载成功");
                        this.m_videoAdIsLoaded = true;
                    }).catch((err) => {
                        this.m_videoAdIsLoaded = false;
                    });
                }
                this.rewardedVideoAd.offClose(onCloseFunc);
            }
            this.rewardedVideoAd.onClose(onCloseFunc);
        } else {
            console.log("初始化失败重新创建加载");
            this.createVideo();
            InsManager.GetInstance()._UIManager.ShowGameToast('视频加载失败，请稍后再试试' , ToastType.Game);
            _failCallback && _failCallback();
            // setTimeout(() => {
            //     if (this.isNoShowVideo == 0) {
            //         console.log("初始化失败重新创建加载播放==" + this.m_videoAdIsLoaded + this.rewardedVideoAd);
            //         this.isNoShowVideo = 1;
            //         this.showVideo("" , _successCallback, _failCallback);
            //     } else {
            //         InsManager.GetInstance()._UIManager.ShowGameToast('视频加载失败，请稍后再试试' , ToastType.Game);
            //         _failCallback && _failCallback();

            //     }
            // }, 1000);
        }

    }
    /**----------原生平台调用----------
     * 激励视频播放成功后调用(OC->TS || JAVA->TS) 
     */
    showVideoAward() {
        this.videoType = "";
        this.arg = null;
    }
    /**----------原生平台调用----------
     * 激励视频播放失败后调用(OC->TS || JAVA->TS) 
     */
    showVideoFail() {
        this.videoType = "";
        this.arg = null;
    }
    /**创建插屏 */
    createInsertAd() {

    }
    /**展示插屏 */
    showInsertAd() {
        // if (this.tt != null && this.tt != undefined) {
        //     let isToutiaio = this.systemInfo.appName === "Toutiao";
        //     // 插屏广告仅今日头条安卓客户端支持
        //     if (isToutiaio) {

        //         this.insertAd = this.tt.createInterstitialAd({
        //             adUnitId: GameIdConfig.toutiaoID["InsertAdId"]
        //         });
        //         this.insertAd
        //             .load()
        //             .then(() => {
        //                 this.insertAd.show();
        //                 //  Platforms.getInstance().sendMessage("showInsertAd","insertAd");
        //             })
        //             .catch(function (err) {
        //                 console.log(err, "插屏错误码");
        //             });
        //     }
        // }
        // console.log("toutiaoH5GameAPI showInsertAd");
    }
    /**创建原生 */
    createNativeAd() {

    }
    /**展示原生 */
    showNativeAd(id: string , _callback: Function) {

    }

    /**震动 */
    public PlayShock() {
        if (!this.tt) return;
        if(this.systemInfo == null){ console.log('获取系统失败'); return;  }

        console.log(this.systemInfo.platform , this.systemInfo.appName , parseInt(this.systemInfo.version[2]))
        console.log(this.systemInfo.version);
        
        if(this.systemInfo.platform == "ios" && this.systemInfo.appName == "Toutiao" && parseInt(this.systemInfo.version[2]) < 7){
            console.log('版本播放震动会有BUG ');
            return;
        }

        this.tt.vibrateShort({
            success(res) {
                // console.log("震动成功");
            },
            fail(res) {
                // console.log(`vibrateShort调用失败`);
            },
        });
    }

    /**原生被点击 */
    onNativeAdClick(_id: string) {

    }
    /**创建原生icon */
    createNativeIconAd() {

    }
    /**展示原生icon */
    showNativeIconAd() {

    }
    /**原生icon被点击 */
    onNativeIconAdClick(_id: string) {

    }
    /**适配不同渠道存储键值对localstorage
     * 默认使用 localStorage
     */
    saveDataToCache(_key: string, _value: any) {

    }
    /**适配不同渠道读取键值对localstorage
     * 默认使用 localStorage
     */
    readDataFromCache(_key: string) { }
    /**添加icon到桌面 */
    addDesktop(_callback: Function) { }

    /**创建更多游戏按钮 */
    createMoreGamesBtn() { }
    /**展示更多游戏按钮 */
    showMoreGamesBtn() {

        console.log("更多游戏");
        if (this.tt != null && this.tt != undefined) {
            if (this.systemInfo.platform == "ios") {
                InsManager.GetInstance()._UIManager.ShowGameToast('抱歉！ios暂不支持' , ToastType.Game);
                return;
            }
            this.tt.showMoreGamesModal && this.tt.showMoreGamesModal({
                appLaunchOptions: [

                ],
                success: () => {

                },
                fail: (err) => {

                }
            })
        }
    }


    addColorBookmark() { }
    addSubscribeApp() { }

    /** 数据打点 */
    ReportAnalytics(eventName: string, data: object){
       if(this.tt){
          this.tt.reportAnalytics(eventName, data);
            if(InsManager.GetInstance()._DataSave.isDebug) console.log( "打点事件保存：" + eventName);
       }
    }

    /**
 * 跳转游戏
 * @param _packageName 包名
 */
    jumpToGame(_packageName: string) { } 
}