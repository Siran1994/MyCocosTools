import { ToastType } from "../../data/GameData";
import { PathData } from "../../data/PathData";
import EventManager from "../../manager/EventManager";
import InsManager from "../../manager/InsManager";
import VivoNativeAdPanel_Ctrl from "../../ui/VivoNativeAdPanel_Ctrl";
import { PlatformsAPI } from "../PlatformsAPI";


export default class HuaWeiH5GameAPI implements PlatformsAPI{
    videoType: string;
    arg: any;

     /**平台环境 */
     private hw: any = window["hbs"];

     /**banner广告 */
     private bannerAd: any = null;
     /**插屏广告 */
     private interstitialAd: any = null;
     /**视频广告 */
     private rewardedVideoAd: any = null;
     /**视频广告是否已经load到数据 */
     private m_videoAdIsLoaded: boolean = false;
     /**分享图地址 */
     private shareUrl: string ="wx_share.jpg";

       /**原生 */
    private nativeAd: any = null;
    private resTemp: any = null;

 
 
     /**设备像素width */
     private windowWidth: number = 0;
     /**设备像素height */
     private windowHeight: number = 0;
     /**系统信息 */
     private systemInfo: any = null;

     private videoId:string="e7hm5vx799";
     private nativeId:string="testu7m3hc4gvm";

    onInit(_callback: Function) {
        if (this.hw) {
            let res = this.hw.getSystemInfoSync();
            try {
                console.log(`手机型号为 ${res.model}`, `手机品牌为 ${res.brand}`);
                this.windowWidth = res.windowWidth;
                this.windowHeight = res.windowHeight;
            } catch (error) {
                console.log(`获取系统信息失败`);
            }
        }
        this.createVideo(this.videoId,null);
        // this.createNativeAd();
        _callback && _callback();
        this.onLogin();
    }
    onLogin() {
        if(this.hw){
            this.hw.gameLoginWithReal({
                forceLogin: 1,
                appid: "103624643",
                success: function (data) {
                    console.log("DUWENJUN game login success:" + data);
                },
                fail: function (data, code) { console.log("game login with real fail:" + data + ", code:" + code); }
            });

            this.hw.onHide(()=>
                {
                    console.log("onHide");
                    // 隐藏原生广告
                    EventManager._Instance.Dispatch_Event(PathData.CLOSENATIVEAD,null);
                }
            );
       }
    }
    onShare(_success: Function) {
        
    }
    onShareVideo(_callback: Function) {
        
    }
    createBanner(id: string) {
        
    }
    showBanner(id: string) {
        
    }
    hideBanner() {
        
    }
    createVideo(id: string, callBack: Function) {
        if (this.hw) {
            this.rewardedVideoAd = this.hw.createRewardedVideoAd({
                adUnitId: id,
                success: (code) => {
                    console.log("ad demo : loadAndShowVideoAd createRewardedVideoAd: success");
                },
                fail: (data, code) => {
                    console.log("ad demo : loadAndShowVideoAd createRewardedVideoAd fail: " + data + "," + code);
                },
                complete: () => {
                    console.log("ad demo : loadAndShowVideoAd createRewardedVideoAd complete");
                }
            });
            this.rewardedVideoAd.load();
            this.rewardedVideoAd.onLoad(() => {
                console.log("onload激励视频广告加载成功");
                this.m_videoAdIsLoaded = true;
            });

            this.rewardedVideoAd.onError((e) => {
                this.m_videoAdIsLoaded = false;
                console.log("onload激励视频广告加载失败-->errMsg:", JSON.stringify(e), e.errMsg, "==>errCode:", e.errCode);
                
            });
        }
    }
    showVideo(id: string, _successCallback?: Function, _failCallback?: Function) {
        if (this.rewardedVideoAd && this.m_videoAdIsLoaded) {
            this.rewardedVideoAd.show();
            const onClose = (res) => {
                if (res.isEnded) {
                    console.log('=========用户是在视频播放完以后关闭的')
                    //console.log("wx平台 激励视频广告播放完成");
                    /**播放完毕 处理播放成功的逻辑 */
                    _successCallback && _successCallback();
                    this.rewardedVideoAd.load();
                } else {
                    // XYX_ToolClass.ToolTips("未完整看完视频无法获得奖励");
                    console.log("=========用户在视频播放过程中关闭的");
                    /**播放失败 处理播放失败的逻辑 */
                    _failCallback && _failCallback("5555");
                    this.rewardedVideoAd.load();
                }
            };
            this.rewardedVideoAd.offClose();
            this.rewardedVideoAd.onClose(onClose);
        } else {
            InsManager.GetInstance()._UIManager.ShowGameToast('广告正在加载中，请稍后再试', ToastType.Hint) ;
            this.createVideo(this.videoId,null);
            console.log("广告在加载中,请稍后再试试");
            // ViewManager.getInstance().showView("HintPanelView",1000,null,true,"视频还未准备好，请稍后再试。。。");

        }
    }
    showVideoAward() {
        
    }
    showVideoFail() {
        
    }
    createInsertAd() {
        
    }
    showInsertAd() {
        
    }
    createNativeAd() {
        if (this.hw) {
            if(this.nativeAd){
                // TipUtils.showTip("Oppo平台 销毁原生广告");
                this.nativeAd = null;
            }
            this.nativeAd = this.hw.createNativeAd({
                adUnitId: this.nativeId,
                success: (code) => {
                    console.log("loadNativeAd loadNativeAd : success");
                },
                fail: (data, code) => {
                    console.log("loadNativeAd loadNativeAd fail: " + data + "," + code);
                },
                complete: () => {
                    console.log("loadNativeAd loadNativeAd : complete");
                }
            });
      }
    }
    showNativeAd(id: string, callBack: Function) {
        if(this.nativeAd){
           
            this.nativeAd.onLoad((res)=>{
                if(res && res.adList){
                    this.resTemp = res.adList[res.adList.length-1];
                    if(this.resTemp){
                        //Laya.timer.once(500,this,()=>{
                            callBack && callBack(this.resTemp);
                            console.log('vivo 原生' , this.resTemp );
                            this.nativeAd.reportAdShow({
                                adId: this.resTemp.adId,
                            });
                            console.log("原生曝光吗", this.resTemp);
                            console.log("原生曝光吗?", this.resTemp.adId);
                            Laya.timer.once(1000,this,()=>{
                                let vivoNativeAdPanel: VivoNativeAdPanel_Ctrl = InsManager.GetInstance()._UIManager.ShowUI(PathData.vivoNativeAdPanel).getComponent(VivoNativeAdPanel_Ctrl);
                                vivoNativeAdPanel.InitView(this.resTemp);
                            });   
                        //})
                    }else{
                       console.log('原生拉取失败');
                    }
                }
            });

            this.nativeAd.onError((err)=>{
                console.log("监听原生广告错误事件", err.errMsg, err.errCode);
               // Game_App._Instance.toastCtrl.OpenSet("Native Error "+ err.errCode);
            });
            this.nativeAd.load();
         
        }
        console.log('vivoH5GameAPI onShowNativeAd');
    }
    onNativeAdClick(_id: string) {
        if (this.nativeAd) {
            console.log(this.nativeAd, this.nativeAd.id, "上报原生点击=======", _id);
            this.nativeAd.reportAdClick({
                adId: _id
            });
        }
    }
    createNativeIconAd() {
        
    }
    showNativeIconAd(id: string, callBack: Function) {
        
    }
    onNativeIconAdClick(_id: string) {
        
    }
    saveDataToCache(_key: string, _value: any) {
        
    }
    readDataFromCache(_key: string) {
        
    }
    addDesktop(_callback: Function) {
        if(this.hw){
            this.hw.hasInstalled({
                success : (res)=> {
                    console.log("hasInstalledsuccess： " + res);
                    if (res) {
                        // 桌面图标已创建    
                        
                    } else {
                        // 桌面图标未创建
                        this.hw.install({
                            message: '创建桌面图标可获得奖励奥！',
                            success:  (res)=> {
                                console.log('handling install success');
                                if(res){
                                    _callback&&_callback(true);
                                }else{
                                    _callback&&_callback(false);
                                }                               
                            },
                            fail: function (erromsg, errocode) {
                                console.log('handling install fail: ' + erromsg + ", errocode: " + errocode);
                            },
                            complete:function() {
                                console.log("handling install  complete");
                            }
                        });
                    }
                },
                fail:function(data){
                    console.log("hasInstalled fail: " + data);
                },
                complete:function() {
                    console.log("hasInstalled complete");
                }
            });
        }
    }
    getDestTop(_callback: Function) {
        if(this.hw){
            this.hw.hasInstalled({
                success : (res)=> {
                    console.log("hasInstalledsuccess： " + res);
                    if (res) {
                        // 桌面图标已创建    
                        _callback&&_callback(true);
                    } else {
                        // 桌面图标未创建
                        _callback&&_callback(false);
                    }
                },
                fail:function(data){
                    console.log("hasInstalled fail: " + data);
                },
                complete:function() {
                    console.log("hasInstalled complete");
                }
            });
        }
    }
    startRecordScreen() {
        
    }
    stopRecordScreen() {
        
    }
    createMoreGamesBtn() {
        
    }
    showMoreGamesBtn() {
        
    }
    jumpToGame(_packageName: string) {
        
    }
    addColorBookmark() {
        
    }
    addSubscribeApp() {
        
    }
    ReportAnalytics(eventName: string, data: object) {
        
    }
    PlayShock() {
        if(this.hw){
            this.hw.vibrateShort({
                success: function () {
                    console.log("vibrateShort success");
                },
                fail: function () {
                    console.log("vibrateShort fail");
                },
                complete: function () {
                    console.log("vibrateShort complete");
                }
            });
        }
    }
    
}